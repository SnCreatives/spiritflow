-- ====================================================================
-- LIQUORFLOW REPAIR MIGRATION: 20261009000002_authoritative_sales_stock_calculation.sql
-- Purpose: Authoritative stock calculation:
--   Current Stock = Opening Stock + Purchased/Inward + Adjustments + Returns - Valid Sales
-- Handles:
--   1. Adds sold_quantity column to public.inventory if missing
--   2. Updates trigger function public.update_inventory_current_stock()
--   3. Automatically synchronizes sold_quantity from sales_transaction_items
--   4. Backfills existing sold_quantity across all bars and products
--   5. Records migration in schema_migrations
-- ====================================================================

-- 1. Ensure sold_quantity column exists on public.inventory
ALTER TABLE public.inventory 
ADD COLUMN IF NOT EXISTS sold_quantity NUMERIC(12, 2) NOT NULL DEFAULT 0;

-- Ensure non-negative check on sold_quantity
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'chk_inventory_sold_quantity_non_negative'
    ) THEN
        ALTER TABLE public.inventory 
        ADD CONSTRAINT chk_inventory_sold_quantity_non_negative CHECK (sold_quantity >= 0);
    END IF;
END $$;

-- 2. Update update_inventory_current_stock trigger function
CREATE OR REPLACE FUNCTION public.update_inventory_current_stock()
RETURNS TRIGGER AS $$
BEGIN
    NEW.sold_quantity := COALESCE(NEW.sold_quantity, 0);
    NEW.opening_quantity := COALESCE(NEW.opening_quantity, 0);
    NEW.purchased_quantity := COALESCE(NEW.purchased_quantity, 0);
    NEW.adjustment_quantity := COALESCE(NEW.adjustment_quantity, 0);
    NEW.returned_quantity := COALESCE(NEW.returned_quantity, 0);

    -- Authoritative Formula: Current = Opening + Purchased + Adjustments + Returned - Sold
    NEW.current_quantity := NEW.opening_quantity + NEW.purchased_quantity + NEW.adjustment_quantity + NEW.returned_quantity - NEW.sold_quantity;
    
    IF NEW.current_quantity < 0 THEN
        RAISE EXCEPTION 'Stock violation: Current stock cannot be negative (calculated: %)', NEW.current_quantity;
    END IF;
    
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 3. Automatic synchronization trigger on sales_transaction_items
CREATE OR REPLACE FUNCTION public.sync_sales_item_to_inventory()
RETURNS TRIGGER AS $$
DECLARE
    target_product_id UUID;
    target_bar_id UUID;
    item_delta NUMERIC(12, 2);
BEGIN
    IF (TG_OP = 'INSERT') THEN
        target_product_id := NEW.product_id;
        target_bar_id := NEW.bar_id;
        item_delta := NEW.quantity;
    ELSIF (TG_OP = 'UPDATE') THEN
        target_product_id := NEW.product_id;
        target_bar_id := NEW.bar_id;
        item_delta := NEW.quantity - OLD.quantity;
    ELSIF (TG_OP = 'DELETE') THEN
        target_product_id := OLD.product_id;
        target_bar_id := OLD.bar_id;
        item_delta := -OLD.quantity;
    END IF;

    IF target_product_id IS NOT NULL AND target_bar_id IS NOT NULL THEN
        UPDATE public.inventory
        SET sold_quantity = GREATEST(0, COALESCE(sold_quantity, 0) + item_delta),
            updated_at = NOW()
        WHERE product_id = target_product_id AND bar_id = target_bar_id;
    END IF;

    IF (TG_OP = 'DELETE') THEN
        RETURN OLD;
    ELSE
        RETURN NEW;
    END IF;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_sales_to_inventory ON public.sales_transaction_items;
CREATE TRIGGER trg_sync_sales_to_inventory
AFTER INSERT OR UPDATE OR DELETE ON public.sales_transaction_items
FOR EACH ROW
EXECUTE FUNCTION public.sync_sales_item_to_inventory();

-- 4. Backfill sold_quantity safely for all existing inventory records
UPDATE public.inventory inv
SET sold_quantity = COALESCE((
    SELECT SUM(sti.quantity)
    FROM public.sales_transaction_items sti
    WHERE sti.product_id = inv.product_id
      AND sti.bar_id = inv.bar_id
), 0),
updated_at = NOW();

-- 5. Record migration status
CREATE TABLE IF NOT EXISTS public.schema_migrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    migration_name VARCHAR(255) UNIQUE NOT NULL,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO public.schema_migrations (migration_name)
VALUES ('20261009000002_authoritative_sales_stock_calculation')
ON CONFLICT (migration_name) DO NOTHING;
