import { getSupabaseServiceClient } from './src/lib/supabase/client';

async function main() {
  const supabase = getSupabaseServiceClient();

  const productIds = ['49503829-7105-45cb-814b-f18a38831121', '9e716d64-5070-4104-a434-156e4b013300'];

  const { data: purchaseItems } = await supabase
    .from('purchase_items')
    .select(`
      id,
      purchase_id,
      product_id,
      quantity,
      purchase:purchases(id, purchase_number, remarks)
    `)
    .in('product_id', productIds);

  console.log('--- Purchase Items for Magic Moments ---');
  for (const item of purchaseItems || []) {
    console.log({
      item_id: item.id,
      product_id: item.product_id,
      quantity: item.quantity,
      purchase_number: (item.purchase as any)?.purchase_number,
      remarks: (item.purchase as any)?.remarks,
    });
  }

  const { data: ledger } = await supabase
    .from('stock_ledger')
    .select('id, product_id, transaction_type, reference_number, stock_in, stock_out, remarks')
    .in('product_id', productIds);

  console.log('--- Stock Ledger for Magic Moments ---');
  for (const entry of ledger || []) {
    console.log({
      id: entry.id,
      product_id: entry.product_id,
      type: entry.transaction_type,
      ref: entry.reference_number,
      in: entry.stock_in,
      out: entry.stock_out,
      remarks: entry.remarks,
    });
  }
}

main().catch(console.error);
