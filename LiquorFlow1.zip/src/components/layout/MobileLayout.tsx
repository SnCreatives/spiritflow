import React, { ReactNode, useState } from 'react';
import {
  Home,
  ArrowDownToLine,
  ShoppingCart,
  Package,
  Menu,
  X,
  Store,
  LogOut,
  Layers,
  Sliders,
  BarChart3,
  ShieldCheck,
  Tag,
  Settings,
  Database,
  Search,
  ChevronRight,
  ClipboardList,
} from 'lucide-react';
import { AuthUser } from '../../types';
import { LiquorFlowLogo } from '../common/LiquorFlowLogo';
import { useBar } from '../../lib/contexts/BarContext';
import { ViewModeToggle } from '../common/ViewModeToggle';

interface MobileLayoutProps {
  user: AuthUser;
  currentRoute: string;
  onRouteChange: (route: string) => void;
  onLogout: () => void;
  onOpenSearch: () => void;
  children: ReactNode;
}

export const MobileLayout: React.FC<MobileLayoutProps> = ({
  user,
  currentRoute,
  onRouteChange,
  onLogout,
  onOpenSearch,
  children,
}) => {
  const { selectedBar } = useBar();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    '1. Masters': false,
    '2. Opening Bal. (01-04-26)': false,
    '3. Received Entry': false,
    '4. Transaction Entry': false,
    '5. Excise Register': false,
    '6. Reports': false,
  });

  const toggleSection = (title: string) => {
    setOpenSections(prev => {
      const next = { ...prev };
      // Show ONLY the tapped group's submenu. Keep other groups collapsed unless deliberately opened.
      Object.keys(next).forEach(key => {
        if (key === title) {
          next[key] = !prev[key];
        } else {
          next[key] = false;
        }
      });
      return next;
    });
  };

  const baseRoute = currentRoute.split('?')[0];

  const handleNavClick = (route: string) => {
    onRouteChange(route);
    setDrawerOpen(false);
  };

  const navItems = [
    {
      id: '/bar-home',
      label: 'Home',
      icon: Home,
      isActive: baseRoute === '/bar-home' || baseRoute === '/' || baseRoute === '',
    },
    {
      id: '/purchases',
      label: 'Inward',
      icon: ArrowDownToLine,
      isActive: baseRoute === '/purchases' || baseRoute === '/received-stock',
    },
    {
      id: '/transactions?tab=add-sale',
      label: 'Sales',
      icon: ShoppingCart,
      isActive: baseRoute.startsWith('/transactions') || baseRoute.startsWith('/sales'),
    },
    {
      id: '/inventory',
      label: 'Stock',
      icon: Package,
      isActive: baseRoute === '/inventory' || baseRoute === '/stock-ledger',
    },
  ];

  const drawerSections = [
    {
      title: '1. Masters',
      items: [
        { label: '1. Licensee Profile', route: '/bar-settings', icon: Store },
        { label: '2. Brand Details', route: '/brands', icon: Tag },
        { label: '3. Add New Brand Details', route: '/products', icon: Package },
        { label: '4. Remove Brands', route: '/pack-sizes', icon: Layers },
      ],
    },
    {
      title: '2. Opening Bal. (01-04-26)',
      items: [
        { label: '1. Opening Stock Details', route: '/stock/opening', icon: Layers },
        { label: '2. Multiple Opening Stock Details', route: '/stock/opening?mode=bulk', icon: Layers },
        { label: '3. Update Opening Stock Details', route: '/stock/adjustments', icon: Sliders },
      ],
    },
    {
      title: '3. Received Entry',
      items: [
        { label: '1. Received From Trader', route: '/purchases', icon: ArrowDownToLine },
        { label: '2. Received From Manufactory', route: '/purchases?type=manufactory', icon: ArrowDownToLine },
        { label: '3. Manual Received Entry', route: '/purchases?type=manual', icon: ArrowDownToLine },
      ],
    },
    {
      title: '4. Transaction Entry',
      items: [
        { label: '1. Sales Entry Daily', route: '/transactions?tab=add-sale', icon: ShoppingCart },
        { label: '2. Multiple Sales Entry', route: '/transactions?tab=range-sales', icon: ShoppingCart },
        { label: '3. Update/Delete Sales Details', route: '/transactions?tab=daily-sales', icon: ShoppingCart },
      ],
    },
    {
      title: '5. Excise Register',
      items: [
        { label: '1. FLR 1A/2A/3A (Brandwise Stock)', route: '/reports?tab=excise-log-book', icon: ShieldCheck },
        { label: '2. FLR 4A (Monthly Statement)', route: '/reports?tab=monthly-report', icon: BarChart3 },
        { label: '3. FLR 1A/2A/3A (Datewise Details)', route: '/reports?tab=daily-sales', icon: ShieldCheck },
      ],
    },
    {
      title: '6. Reports',
      items: [
        { label: '1. Brandwise Stock Details', route: '/inventory', icon: BarChart3 },
        { label: '2. Brand Summary Details', route: '/reports?tab=sales-summary', icon: BarChart3 },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans max-w-full overflow-x-hidden selection:bg-amber-500 selection:text-slate-950">
      {/* 1. Mobile Top Bar */}
      <header className="fixed top-0 inset-x-0 h-14 bg-white border-b border-slate-200 z-40 px-3 flex items-center justify-between shadow-xs pt-[env(safe-area-inset-top)]">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            aria-label="Open Navigation Menu"
            className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-slate-100 active:bg-slate-200 text-slate-700 transition-colors shrink-0 cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => handleNavClick('/bar-home')}
            className="flex items-center gap-1.5 focus:outline-none shrink-0"
          >
            <LiquorFlowLogo size="xs" variant="mark" theme="light" />
            <span className="font-black text-sm tracking-tight text-slate-900 uppercase">
              Liquor<span className="text-amber-600">Flow</span>
            </span>
          </button>
        </div>

        {/* View Mode Toggle & Bar Quick Info */}
        <div className="flex items-center gap-1.5 shrink-0">
          <ViewModeToggle variant="compact" />

          {selectedBar && (
            <button
              type="button"
              onClick={() => handleNavClick('/bar-home')}
              className="h-8 max-w-[100px] sm:max-w-[140px] px-2 rounded-lg bg-amber-50 border border-amber-200/60 flex items-center gap-1 text-[11px] font-bold text-amber-900 truncate"
              title={selectedBar.name}
            >
              <Store className="w-3 h-3 text-amber-600 shrink-0" />
              <span className="truncate">{selectedBar.name}</span>
            </button>
          )}

          <button
            type="button"
            onClick={onLogout}
            title="Log Out"
            className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* 2. Slide-over Mobile Navigation Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={() => setDrawerOpen(false)}
          />

          {/* Drawer Panel */}
          <div className="relative w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)] animate-in slide-in-from-left duration-200">
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
              <div className="flex items-center gap-2.5">
                <LiquorFlowLogo size="xs" variant="mark" theme="dark" />
                <div>
                  <h3 className="font-black text-sm uppercase tracking-tight text-white">
                    Liquor<span className="text-amber-500">Flow</span>
                  </h3>
                  <p className="text-[10px] text-slate-400 font-bold truncate max-w-[180px]">
                    {selectedBar?.name || 'No Bar Selected'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="w-8 h-8 rounded-lg bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick View Mode Switcher in Drawer */}
            <div className="p-3 bg-slate-50 border-b border-slate-200">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 block mb-1.5">
                Layout Preference
              </span>
              <ViewModeToggle variant="compact" />
            </div>

            {/* Navigation Sections */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-sky-50/40">
              {drawerSections.map((sec) => {
                const isOpen = openSections[sec.title];
                const hasActiveChild = sec.items.some(item => baseRoute === item.route.split('?')[0]);

                return (
                  <div key={sec.title} className="space-y-1">
                    {/* Collapsible Header Button */}
                    <button
                      type="button"
                      onClick={() => toggleSection(sec.title)}
                      className={`w-full min-h-[44px] px-3 py-2.5 rounded-xl flex items-center justify-between text-xs font-black transition-all cursor-pointer border ${
                        hasActiveChild
                          ? 'bg-amber-500/10 text-slate-900 border-amber-500/30'
                          : 'bg-white text-slate-800 border-slate-200 shadow-xs'
                      }`}
                    >
                      <span>{sec.title}</span>
                      {isOpen ? (
                        <ChevronRight className="w-4 h-4 text-amber-600 rotate-90 transition-transform" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-slate-400 transition-transform" />
                      )}
                    </button>

                    {/* Collapsible Submenu */}
                    {isOpen && (
                      <div className="pl-3.5 border-l-2 border-amber-500/40 mt-1 space-y-1">
                        {sec.items.map((item) => {
                          const isActive = baseRoute === item.route.split('?')[0];
                          const Icon = item.icon;
                          return (
                            <button
                              key={item.route}
                              type="button"
                              onClick={() => handleNavClick(item.route)}
                              className={`w-full min-h-[40px] px-3 py-2 rounded-lg flex items-center gap-3 text-xs font-bold transition-all cursor-pointer ${
                                isActive
                                  ? 'bg-amber-400 text-slate-950 font-black shadow-xs'
                                  : 'text-slate-700 bg-white/70 hover:bg-slate-100 border border-slate-100'
                              }`}
                            >
                              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                              <span>{item.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}

              {/* 7. Log Out group */}
              <div className="pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    onLogout();
                  }}
                  className="w-full min-h-[44px] px-3 py-2.5 rounded-xl flex items-center gap-3 text-xs font-black bg-rose-50 border border-rose-200/50 text-rose-700 transition-all cursor-pointer shadow-xs"
                >
                  <LogOut className="w-4 h-4 text-rose-500" />
                  <span>7. Log Out</span>
                </button>
              </div>
            </div>

            {/* Drawer Footer with User & Logout */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-black text-slate-700">
                  {user.email ? user.email.charAt(0).toUpperCase() : 'U'}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-black text-slate-900 truncate max-w-[120px]">{user.email}</p>
                  <p className="text-[10px] text-slate-500 font-medium capitalize">{user.role || 'User'}</p>
                </div>
              </div>

              <button
                type="button"
                onClick={onLogout}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-bold transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Exit</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Main Content Container (Padded for mobile top & bottom nav) */}
      <main className="flex-1 w-full max-w-full overflow-x-hidden pt-15 pb-20 px-3 sm:px-4">
        {children}
      </main>

      {/* 4. Bottom Navigation Bar */}
      <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-slate-200 z-40 px-2 py-1 flex items-center justify-around shadow-lg pb-[max(env(safe-area-inset-bottom),0.35rem)]">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNavClick(item.id)}
              className={`flex-1 min-h-[46px] py-1 flex flex-col items-center justify-center gap-0.5 rounded-xl transition-all cursor-pointer active:scale-95 ${
                item.isActive
                  ? 'text-amber-600 font-black'
                  : 'text-slate-500 hover:text-slate-900 font-medium'
              }`}
            >
              <div
                className={`p-1 rounded-lg transition-colors ${
                  item.isActive ? 'bg-amber-500/10' : ''
                }`}
              >
                <Icon className={`w-5 h-5 ${item.isActive ? 'text-amber-600' : 'text-slate-500'}`} />
              </div>
              <span className="text-[10px] tracking-tight">{item.label}</span>
            </button>
          );
        })}

        {/* 'More' Button to toggle Drawer */}
        <button
          type="button"
          onClick={() => setDrawerOpen(true)}
          className={`flex-1 min-h-[46px] py-1 flex flex-col items-center justify-center gap-0.5 rounded-xl transition-all cursor-pointer active:scale-95 ${
            drawerOpen
              ? 'text-amber-600 font-black'
              : 'text-slate-500 hover:text-slate-900 font-medium'
          }`}
        >
          <div className="p-1 rounded-lg">
            <Menu className="w-5 h-5 text-slate-500" />
          </div>
          <span className="text-[10px] tracking-tight">More</span>
        </button>
      </nav>
    </div>
  );
};
