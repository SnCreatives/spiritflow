import React from 'react';
import { Monitor, Smartphone, Cpu } from 'lucide-react';
import { useViewMode, ViewMode } from '../../lib/contexts/ViewModeContext';

interface ViewModeToggleProps {
  variant?: 'compact' | 'expanded';
  className?: string;
}

export const ViewModeToggle: React.FC<ViewModeToggleProps> = ({
  variant = 'compact',
  className = '',
}) => {
  const { viewMode, effectiveMode, setViewMode, isAuto } = useViewMode();

  if (variant === 'expanded') {
    return (
      <div className={`space-y-3 ${className}`}>
        <div className="flex items-center justify-between">
          <div>
            <label className="text-xs font-black uppercase tracking-wider text-slate-700 block">
              Display & Layout Experience
            </label>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Choose between full desktop ergonomics or mobile-first touch interfaces.
            </p>
          </div>
          {isAuto && (
            <span className="text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200/60 px-2 py-0.5 rounded-md">
              Auto: {effectiveMode === 'mobile' ? 'Mobile Active' : 'Desktop Active'}
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <button
            type="button"
            onClick={() => setViewMode('desktop')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
              viewMode === 'desktop'
                ? 'bg-amber-500/10 border-amber-500 text-slate-900 shadow-sm ring-1 ring-amber-500'
                : 'bg-white border-slate-200 hover:border-slate-300 text-slate-600'
            }`}
          >
            <div className="flex items-center gap-2">
              <Monitor className={`w-4 h-4 ${viewMode === 'desktop' ? 'text-amber-600' : 'text-slate-400'}`} />
              <span className="text-xs font-black uppercase tracking-tight">Desktop View</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-relaxed">
              Wide tables, multi-column forms, full sidebar, and dense data displays.
            </p>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('mobile')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
              viewMode === 'mobile'
                ? 'bg-amber-500/10 border-amber-500 text-slate-900 shadow-sm ring-1 ring-amber-500'
                : 'bg-white border-slate-200 hover:border-slate-300 text-slate-600'
            }`}
          >
            <div className="flex items-center gap-2">
              <Smartphone className={`w-4 h-4 ${viewMode === 'mobile' ? 'text-amber-600' : 'text-slate-400'}`} />
              <span className="text-xs font-black uppercase tracking-tight">Mobile View</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-relaxed">
              Touch cards, bottom navigation bar, stacked forms, and zero horizontal scroll.
            </p>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('auto')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
              viewMode === 'auto'
                ? 'bg-amber-500/10 border-amber-500 text-slate-900 shadow-sm ring-1 ring-amber-500'
                : 'bg-white border-slate-200 hover:border-slate-300 text-slate-600'
            }`}
          >
            <div className="flex items-center gap-2">
              <Cpu className={`w-4 h-4 ${viewMode === 'auto' ? 'text-amber-600' : 'text-slate-400'}`} />
              <span className="text-xs font-black uppercase tracking-tight">Auto (Device)</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-relaxed">
              Automatically selects based on current screen width ({effectiveMode} now).
            </p>
          </button>
        </div>
      </div>
    );
  }

  // Compact variant for Header
  return (
    <div className={`inline-flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200/80 ${className}`}>
      <button
        type="button"
        onClick={() => setViewMode('desktop')}
        title="Switch to Desktop View"
        aria-label="Desktop View"
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
          viewMode === 'desktop'
            ? 'bg-white text-slate-900 shadow-xs border border-slate-200/60 font-black'
            : effectiveMode === 'desktop' && isAuto
            ? 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/50'
            : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200/50'
        }`}
      >
        <Monitor className="w-3.5 h-3.5 shrink-0" />
        <span className="hidden sm:inline">Desktop</span>
      </button>

      <button
        type="button"
        onClick={() => setViewMode('mobile')}
        title="Switch to Mobile View"
        aria-label="Mobile View"
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
          viewMode === 'mobile'
            ? 'bg-white text-slate-900 shadow-xs border border-slate-200/60 font-black'
            : effectiveMode === 'mobile' && isAuto
            ? 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/50'
            : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200/50'
        }`}
      >
        <Smartphone className="w-3.5 h-3.5 shrink-0" />
        <span className="hidden sm:inline">Mobile</span>
      </button>

      <button
        type="button"
        onClick={() => setViewMode('auto')}
        title={`Reset to Automatic Mode (currently ${effectiveMode})`}
        aria-label="Auto Mode"
        className={`flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer ${
          isAuto
            ? 'bg-amber-500 text-slate-950 shadow-xs font-black'
            : 'text-slate-400 hover:text-slate-700 hover:bg-slate-200/50'
        }`}
      >
        <Cpu className="w-3 h-3 shrink-0" />
        <span className="hidden md:inline">Auto</span>
      </button>
    </div>
  );
};
