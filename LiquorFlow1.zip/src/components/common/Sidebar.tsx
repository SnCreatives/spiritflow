import React, { useState, useEffect } from 'react';
import {
  Home,
  Package,
  ShoppingCart,
  BarChart3,
  Sliders,
  ChevronDown,
  ChevronRight,
  Store,
  User,
  ArrowDownToLine,
  FileSpreadsheet,
  ShieldCheck,
  Database,
  Layers,
  LogOut,
  Tag,
  ClipboardList,
} from 'lucide-react';
import { AuthUser } from '../../types';
import { LiquorFlowLogo } from './LiquorFlowLogo';
import { useBar } from '../../lib/contexts/BarContext';

interface SidebarProps {
  currentRoute: string;
  onRouteChange: (route: string) => void;
  user: AuthUser | null;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentRoute,
  onRouteChange,
  user,
  onLogout,
}) => {
  const { selectedBar } = useBar();

  // Collapsible accordion group states
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    masters: false,
    openingBal: false,
    receivedEntry: true,
    transactionEntry: false,
    exciseRegister: false,
    reports: false,
  });

  // Auto-expand group when route matches
  useEffect(() => {
    const route = currentRoute.split('?')[0];
    if (['/bar-settings', '/bars', '/user-settings', '/settings', '/brands', '/products', '/pack-sizes'].includes(route)) {
      setOpenGroups(prev => ({ ...prev, masters: true }));
    } else if (['/stock/opening', '/opening-stock', '/stock/adjustments'].includes(route)) {
      setOpenGroups(prev => ({ ...prev, openingBal: true }));
    } else if (['/purchases', '/received-stock'].includes(route)) {
      setOpenGroups(prev => ({ ...prev, receivedEntry: true }));
    } else if (route.startsWith('/transactions') || route.startsWith('/sales')) {
      setOpenGroups(prev => ({ ...prev, transactionEntry: true }));
    } else if (route.startsWith('/reports') && (currentRoute.includes('excise-log-book') || currentRoute.includes('monthly-report'))) {
      setOpenGroups(prev => ({ ...prev, exciseRegister: true }));
    } else if (['/inventory', '/stock-ledger'].includes(route) || (route.startsWith('/reports') && currentRoute.includes('sales-summary'))) {
      setOpenGroups(prev => ({ ...prev, reports: true }));
    }
  }, [currentRoute]);

  const toggleGroup = (key: string) => {
    setOpenGroups(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Exact Maharashtra State Excise Retailer Management System structure
  const modules = [
    {
      key: 'masters',
      label: '1. Masters',
      icon: Store,
      items: [
        { id: '/bar-settings', label: '1. Licensee Profile' },
        { id: '/brands', label: '2. Brand Details' },
        { id: '/products', label: '3. Add New Brand Details' },
        { id: '/pack-sizes', label: '4. Remove Brands' },
      ],
    },
    {
      key: 'openingBal',
      label: '2. Opening Bal. (01-04-26)',
      icon: Layers,
      items: [
        { id: '/stock/opening', label: '1. Opening Stock Details' },
        { id: '/stock/opening?mode=bulk', label: '2. Multiple Opening Stock Details' },
        { id: '/stock/adjustments', label: '3. Update Opening Stock Details' },
      ],
    },
    {
      key: 'receivedEntry',
      label: '3. Received Entry',
      icon: ArrowDownToLine,
      items: [
        { id: '/purchases', label: '1. Received From Trader' },
        { id: '/purchases?type=manufactory', label: '2. Received From Manufactory' },
        { id: '/purchases?type=manual', label: '3. Manual Received Entry' },
      ],
    },
    {
      key: 'transactionEntry',
      label: '4. Transaction Entry',
      icon: ShoppingCart,
      items: [
        { id: '/transactions?tab=add-sale', label: '1. Sales Entry Daily' },
        { id: '/transactions?tab=range-sales', label: '2. Multiple Sales Entry' },
        { id: '/transactions?tab=daily-sales', label: '3. Update/Delete Sales Details' },
      ],
    },
    {
      key: 'exciseRegister',
      label: '5. Excise Register',
      icon: ShieldCheck,
      items: [
        { id: '/reports?tab=excise-log-book', label: '1. FLR 1A/2A/3A (Brandwise Stock)' },
        { id: '/reports?tab=monthly-report', label: '2. FLR 4A (Monthly Statement)' },
        { id: '/reports?tab=daily-sales', label: '3. FLR 1A/2A/3A (Datewise Details)' },
      ],
    },
    {
      key: 'reports',
      label: '6. Reports',
      icon: BarChart3,
      items: [
        { id: '/inventory', label: '1. Brandwise Stock Details' },
        { id: '/reports?tab=sales-summary', label: '2. Brand Summary Details' },
      ],
    },
  ];

  const isItemActive = (itemId: string) => {
    if (itemId === currentRoute) return true;
    const currentBase = currentRoute.split('?')[0];
    const itemBase = itemId.split('?')[0];

    // Check if query parameter matches
    if (itemId.includes('?')) {
      if (currentRoute.includes('?')) {
        return itemId === currentRoute;
      }
      return itemId === (currentRoute + window.location.search);
    }

    return currentBase === itemBase;
  };

  const isBarHomeActive = currentRoute === '/bar-home' || currentRoute === '/' || currentRoute === '';

  return (
    <aside className="w-64 bg-[#0f172a] text-slate-300 border-r border-slate-800 min-h-screen flex flex-col justify-between select-none font-sans overflow-hidden">
      <div className="flex-1 py-5 px-3 space-y-4 overflow-y-auto scrollbar-hide">
        {/* Brand Logo */}
        <button
          type="button"
          onClick={() => onRouteChange('/bar-home')}
          className="w-full text-left px-2 mb-1 cursor-pointer focus:outline-none transition-transform hover:scale-[1.02] active:scale-100"
        >
          <LiquorFlowLogo size="md" variant="full" theme="dark" />
        </button>

        {/* Current Bar Status & Link to Bar Home */}
        <button
          type="button"
          onClick={() => onRouteChange('/bar-home')}
          className="w-full text-left px-3 py-2.5 bg-slate-800/40 hover:bg-slate-800 transition-all border border-slate-700/50 rounded-xl cursor-pointer group"
        >
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center justify-between mb-0.5">
            <span>Outlet</span>
            <span className="text-[9px] text-amber-400 font-bold bg-amber-900/30 px-1.5 py-0.2 rounded border border-amber-800/50 group-hover:bg-amber-800/50 transition-colors">Switch</span>
          </div>
          <div className="text-xs font-bold text-white truncate">
            {selectedBar?.name || 'No Bar Selected'}
          </div>
        </button>

        {/* Navigation Sections */}
        <nav className="space-y-1">
          {/* Home Link */}
          <button
            type="button"
            onClick={() => onRouteChange('/bar-home')}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              isBarHomeActive
                ? 'bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Home className="w-4 h-4 shrink-0" />
            <span>Dashboard Overview</span>
          </button>

          {/* Numbered Sections 1 to 6 */}
          <div className="pt-2 space-y-1.5">
            {modules.map((module) => {
              const isOpen = openGroups[module.key];
              const Icon = module.icon;
              const hasActiveChild = module.items.some(item => isItemActive(item.id));

              return (
                <div key={module.key} className="space-y-0.5">
                  <button
                    type="button"
                    onClick={() => toggleGroup(module.key)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer group ${
                      hasActiveChild
                        ? 'text-amber-400 bg-slate-800/60'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 ${hasActiveChild ? 'text-amber-400' : 'text-slate-500 group-hover:text-slate-300'}`} />
                      <span className="tracking-tight">{module.label}</span>
                    </div>
                    {isOpen ? (
                      <ChevronDown className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-400" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-400" />
                    )}
                  </button>

                  {isOpen && (
                    <div className="ml-4 pl-3 border-l border-slate-800 mt-0.5 space-y-0.5">
                      {module.items.map((item) => {
                        const active = isItemActive(item.id);

                        return (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => onRouteChange(item.id)}
                            className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs transition-all cursor-pointer text-left ${
                              active
                                ? 'bg-amber-500/10 text-amber-400 font-bold'
                                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
                            }`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${active ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]' : 'bg-slate-700'}`} />
                            <span className="truncate">{item.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}

            {/* 7. Log Out */}
            <div className="pt-2 border-t border-slate-800/60">
              <button
                type="button"
                onClick={onLogout}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-all cursor-pointer"
              >
                <LogOut className="w-4 h-4 shrink-0" />
                <span>7. Log Out</span>
              </button>
            </div>
          </div>
        </nav>
      </div>

      {/* User Info Footer */}
      {user && (
        <div className="p-3 border-t border-slate-800 bg-[#0f172a] flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center font-bold text-xs shrink-0">
              {user.username ? user.username.slice(0, 1).toUpperCase() : 'U'}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-bold text-white truncate">
                {user.username || 'Admin User'}
              </div>
              <div className="text-[10px] text-slate-500 truncate font-medium">
                {user.email || 'Bar Manager'}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onLogout}
            title="Log Out"
            className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </aside>
  );
};
