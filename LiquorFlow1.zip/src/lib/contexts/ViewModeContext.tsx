import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';

export type ViewMode = 'auto' | 'desktop' | 'mobile';
export type EffectiveMode = 'desktop' | 'mobile';

interface ViewModeContextType {
  viewMode: ViewMode;
  effectiveMode: EffectiveMode;
  setViewMode: (mode: ViewMode) => void;
  isAuto: boolean;
}

const STORAGE_KEY = 'liquorflow_view_mode';

const ViewModeContext = createContext<ViewModeContextType | undefined>(undefined);

export const ViewModeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [viewMode, setViewModeState] = useState<ViewMode>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored === 'desktop' || stored === 'mobile' || stored === 'auto') {
        return stored;
      }
    } catch {
      // ignore storage errors
    }
    return 'auto';
  });

  const [deviceIsMobile, setDeviceIsMobile] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return window.innerWidth < 768;
  });

  // Track window resize for 'auto' mode
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const mediaQuery = window.matchMedia('(max-width: 767px)');
    const handleMediaChange = (e: MediaQueryListEvent | MediaQueryList) => {
      setDeviceIsMobile(e.matches);
    };

    setDeviceIsMobile(mediaQuery.matches);

    try {
      mediaQuery.addEventListener('change', handleMediaChange);
      return () => mediaQuery.removeEventListener('change', handleMediaChange);
    } catch {
      // Fallback for older browsers
      const handleResize = () => {
        setDeviceIsMobile(window.innerWidth < 768);
      };
      window.addEventListener('resize', handleResize);
      return () => window.removeEventListener('resize', handleResize);
    }
  }, []);

  const setViewMode = useCallback((mode: ViewMode) => {
    setViewModeState(mode);
    try {
      localStorage.setItem(STORAGE_KEY, mode);
    } catch {
      // ignore storage error
    }
  }, []);

  const effectiveMode: EffectiveMode =
    viewMode === 'desktop'
      ? 'desktop'
      : viewMode === 'mobile'
      ? 'mobile'
      : deviceIsMobile
      ? 'mobile'
      : 'desktop';

  const isAuto = viewMode === 'auto';

  return (
    <ViewModeContext.Provider
      value={{
        viewMode,
        effectiveMode,
        setViewMode,
        isAuto,
      }}
    >
      {children}
    </ViewModeContext.Provider>
  );
};

export const useViewMode = (): ViewModeContextType => {
  const context = useContext(ViewModeContext);
  if (!context) {
    throw new Error('useViewMode must be used within a ViewModeProvider');
  }
  return context;
};
