import dotenv from 'dotenv';
dotenv.config();

import { getSupabaseServiceClient } from '../lib/supabase/client.js';

async function auditScmSchema() {
  const supabase = getSupabaseServiceClient();
  console.log('=== AUDITING EXISTING DATABASE SCHEMA FOR SCM & BRAND MASTER ===\n');

  // Check categories
  const { data: categories } = await supabase.from('categories').select('id, name, code');
  console.log('Categories Count:', categories?.length || 0);

  // Check pack_sizes
  const { data: packSizes } = await supabase.from('pack_sizes').select('id, name, volume_ml, pack_type, category_id');
  console.log('Pack Sizes Count:', packSizes?.length || 0);

  // Check brands
  const { data: brands } = await supabase.from('brands').select('id, name, brand_name, category_id');
  console.log('Brands Count:', brands?.length || 0);

  // Check products
  const { data: products } = await supabase.from('products').select('id, name, product_name, sku, brand_id, category_id, pack_size_id');
  console.log('Products Count:', products?.length || 0);

  // Check scm_codes table
  const { data: scm, error: scmErr } = await supabase.from('scm_codes').select('*').limit(5);
  console.log('scm_codes Table Query Result:', { exists: !scmErr, count: scm?.length, error: scmErr?.message });
}

auditScmSchema().catch(console.error);
