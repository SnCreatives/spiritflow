import fs from 'fs';
import path from 'path';
import Papa from 'papaparse';
import dotenv from 'dotenv';
dotenv.config();

import { ProductMasterService } from '../server/services/productMasterService.js';
import { getSupabaseServiceClient } from '../lib/supabase/client.js';

async function runSeed() {
  console.log('--- Starting Source Catalog Bulk Import & Master Seed ---');
  
  const csvPath = path.join(process.cwd(), 'src', 'data', 'sourceCatalogData.csv');
  if (!fs.existsSync(csvPath)) {
    console.error(`CSV file not found at ${csvPath}`);
    process.exit(1);
  }

  const csvContent = fs.readFileSync(csvPath, 'utf-8');
  const parseResult = Papa.parse(csvContent, { header: true, skipEmptyLines: true });
  const rows: any[] = parseResult.data;

  console.log(`Total rows read from CSV file: ${rows.length}`);

  // 1. Run Validation & Import Preview
  const preview = await ProductMasterService.validateImportBatch(rows);
  console.log('\n--- IMPORT PREVIEW SUMMARY ---');
  console.log(`Total Rows: ${preview.totalRows}`);
  console.log(`Unique Brands Detected: ${preview.uniqueBrandsCount}`);
  console.log(`New SCM Code Mappings: ${preview.newScmMappingsCount}`);
  console.log(`Duplicate Rows Detected: ${preview.duplicateRowsCount}`);
  console.log(`Rows Requiring Category Review: ${preview.rowsRequiringReviewCount}`);
  console.log('Categories Breakdown:', preview.categoriesDetected);

  // 2. Execute Resolution & Database Commit
  console.log('\n--- EXECUTING DATABASE COMMIT ---');
  const resolveResults = await ProductMasterService.bulkResolveAndCreate(rows);
  
  const successRows = resolveResults.filter(r => r.status === 'valid');
  const failedRows = resolveResults.filter(r => r.status === 'invalid');

  console.log(`Successfully Processed Rows: ${successRows.length}`);
  console.log(`Failed Rows: ${failedRows.length}`);

  if (failedRows.length > 0) {
    console.warn('Sample Errors:', failedRows.slice(0, 5).map(f => f.errorMessage));
  }

  // 3. Confirm Database Counts
  const supabase = getSupabaseServiceClient();
  const [bRes, cRes, pRes, scmRes] = await Promise.all([
    supabase.from('brands').select('id', { count: 'exact' }),
    supabase.from('categories').select('id', { count: 'exact' }),
    supabase.from('products').select('id', { count: 'exact' }),
    supabase.from('scm_codes').select('id', { count: 'exact' }),
  ]);

  console.log('\n--- DATABASE RECORD VERIFICATION ---');
  console.log(`Total Brands in DB: ${bRes.count}`);
  console.log(`Total Categories in DB: ${cRes.count}`);
  console.log(`Total Products in DB: ${pRes.count}`);
  console.log(`Total SCM Code Mappings in DB: ${scmRes.count}`);
  console.log('--- Seed Process Complete ---');
}

runSeed().catch(err => {
  console.error('Fatal error in seed execution:', err);
  process.exit(1);
});
