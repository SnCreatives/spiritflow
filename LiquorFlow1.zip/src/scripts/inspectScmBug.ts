import { getSupabaseServiceClient } from '../lib/supabase/client.js';
import dotenv from 'dotenv';
dotenv.config();

async function inspectScm() {
  const supabase = getSupabaseServiceClient();
  
  const scmRes = await supabase
    .from('scm_codes')
    .select('*, product:products(*, pack_size:pack_sizes(*))')
    .in('scm_code', ['SCMPL0043362', 'SCMPL0043364', 'SCMPL0043361', 'SCMPL0043360']);

  console.log('SCM Codes in DB:', JSON.stringify(scmRes.data, null, 2));

  const prodRes = await supabase
    .from('products')
    .select('*, pack_size:pack_sizes(*)')
    .or('sku.eq.SCMPL0043362,sku.eq.SCMPL0043364,name.ilike.%AB Classic Gold%');

  console.log('Products in DB:', JSON.stringify(prodRes.data, null, 2));
}

inspectScm();
