import { getSupabaseServiceClient } from '../../lib/supabase/client.js';
import { ScmService } from './scmService.js';

export type CanonicalProductType = 'Wine' | 'Fermented Beer' | 'Mild Beer' | 'Spirit';

export const CANONICAL_PRODUCT_TYPES: CanonicalProductType[] = [
  'Spirit',
  'Wine',
  'Fermented Beer',
  'Mild Beer',
];

export const SPIRIT_SUBCATEGORIES = [
  'Whiskey',
  'Gin',
  'Vodka',
  'Tequila',
  'Rum',
  'Brandy',
] as const;

export const ALLOWED_BOTTLE_SIZES: Record<CanonicalProductType, number[]> = {
  'Spirit': [2000, 1000, 750, 375, 180, 90, 200], // 200ml strictly conditionally allowed
  'Mild Beer': [650, 500, 330],
  'Fermented Beer': [650, 500, 330],
  'Wine': [750, 375, 180, 90],
};

export const ALLOWED_PACKAGING_TYPES = ['Bottle', 'Can', 'Case', 'Keg', 'Pouch'] as const;

export interface CascadingQuery {
  productType?: string;
  categoryId?: string;
  brandId?: string;
  variant?: string;
  packSizeId?: string;
  volumeMl?: number;
  packagingType?: string;
}

export interface CascadingResponse {
  productTypes: string[];
  categories: Array<{ id: string; name: string; productType: string; code?: string }>;
  brands: Array<{ id: string; name: string; categoryId: string; productType?: string }>;
  variants: string[];
  packSizes: Array<{ id: string; name: string; volumeMl: number; packType: string }>;
  packagingTypes: string[];
  products: Array<{
    id: string;
    name: string;
    productName: string;
    variant: string;
    brandId: string;
    brandName?: string;
    categoryId: string;
    categoryName?: string;
    productType?: string;
    packSizeId: string;
    volumeMl?: number;
    packType: string;
    mrp: number;
    purchasePrice: number;
    sku: string;
    status: string;
    activeScmCode?: string | null;
  }>;
}

export class ProductMasterService {
  /**
   * Normalize and resolve Product Type from Category Name/Code
   */
  static resolveProductType(categoryNameOrCode: string): CanonicalProductType {
    const raw = (categoryNameOrCode || '').trim().toLowerCase();
    if (raw.includes('wine')) return 'Wine';
    if (raw.includes('mild beer') || raw === 'mild') return 'Mild Beer';
    if (raw.includes('fermented') || raw.includes('strong beer') || raw === 'beer') return 'Fermented Beer';
    return 'Spirit'; // Default for Whisky, Rum, Vodka, Gin, Brandy, Tequila, Liqueurs
  }

  /**
   * Validate that bottle volume is allowed for the specific product type
   */
  static validateBottleSize(productType: CanonicalProductType, volumeMl: number, isWhisky = false, allow200Special = false): void {
    const allowed = ALLOWED_BOTTLE_SIZES[productType] || [];
    if (!allowed.includes(volumeMl)) {
      throw new Error(`Bottle size ${volumeMl} ml is not permitted for product type "${productType}". Allowed sizes: ${allowed.join(', ')} ml.`);
    }

    if (volumeMl === 2000 && productType === 'Spirit' && !isWhisky) {
      throw new Error('2000 ml bottle size is restricted to applicable Whisky products only.');
    }

    if (volumeMl === 200 && productType === 'Spirit' && !allow200Special) {
      throw new Error('200 ml bottle size is not automatically available for all spirit products.');
    }
  }

  /**
   * Fetch all canonical product categories with normalized product types
   */
  static async getCategories() {
    const supabase = getSupabaseServiceClient();
    let cats: any[] | null = null;

    const { data: rawCats, error } = await supabase
      .from('categories')
      .select('*')
      .order('name');

    if (!error && rawCats) {
      const activeCats = rawCats.filter(c => c.active !== false);
      cats = activeCats.length > 0 ? activeCats : rawCats;
    } else {
      const { data: fallbackCats } = await supabase
        .from('categories')
        .select('id, name, code, active')
        .order('name');
      const activeFallback = (fallbackCats || []).filter(c => c.active !== false);
      cats = activeFallback.length > 0 ? activeFallback : (fallbackCats || []);
    }

    return (cats || []).map(c => {
      const pType = c.product_type || this.resolveProductType(c.name || c.code);
      return {
        ...c,
        product_type: pType,
      };
    });
  }

  /**
   * Global Brand Master retrieval with normalization
   */
  static async getBrands(params?: { categoryId?: string; productType?: string; search?: string }) {
    const supabase = getSupabaseServiceClient();
    let query = supabase.from('brands').select('id, name, brand_name, category_id, active, registration_reference');

    if (params?.categoryId) {
      query = query.eq('category_id', params.categoryId);
    }
    if (params?.search) {
      const s = params.search.trim();
      query = query.or(`name.ilike.%${s}%,brand_name.ilike.%${s}%`);
    }

    const { data: brands, error } = await query.order('name');
    if (error) throw new Error(`Failed to fetch brands: ${error.message}`);

    return (brands || []).map(b => ({
      ...b,
      name: (b.brand_name || b.name || '').trim(),
    }));
  }

  /**
   * Create or normalize Brand with duplicate prevention
   */
  static async createBrand(input: { name: string; categoryId: string; registrationReference?: string }) {
    const cleanName = (input.name || '').trim();
    if (!cleanName) throw new Error('Brand name cannot be empty.');
    if (!input.categoryId) throw new Error('Brand must be associated with a valid Category.');

    const supabase = getSupabaseServiceClient();

    // Check for duplicate brand (case-insensitive)
    const { data: existing } = await supabase
      .from('brands')
      .select('id, name, brand_name, category_id')
      .ilike('name', cleanName)
      .eq('category_id', input.categoryId)
      .maybeSingle();

    if (existing) {
      return existing;
    }

    const { data: created, error } = await supabase
      .from('brands')
      .insert({
        name: cleanName,
        brand_name: cleanName,
        category_id: input.categoryId,
        registration_reference: input.registrationReference || null,
        active: true,
      })
      .select()
      .single();

    if (error) throw new Error(`Failed to create brand: ${error.message}`);
    return created;
  }

  /**
   * Canonical Cascading Dropdown API
   * Logical flow: Product Type -> Brand -> Variant -> Bottle Size -> Packaging -> Product -> MRP / SCM Code
   */
  static async getCascadingData(query: CascadingQuery = {}): Promise<CascadingResponse> {
    const supabase = getSupabaseServiceClient();

    // 1. Fetch categories
    const categories = await this.getCategories();
    let filteredCategories = categories;

    if (query.productType) {
      filteredCategories = categories.filter(c => {
        const pType = (c.product_type || '').toLowerCase();
        const qType = (query.productType || '').toLowerCase();
        if (pType === qType) return true;
        if (qType.includes('beer') && pType.includes('beer')) return true;
        return false;
      });
    }

    const categoryIds = filteredCategories.map(c => c.id);

    // 2. Fetch brands
    let brands = await this.getBrands();
    if (query.categoryId) {
      const direct = brands.filter(b => b.category_id === query.categoryId);
      if (direct.length > 0) {
        brands = direct;
      } else {
        const targetCat = categories.find(c => c.id === query.categoryId);
        if (targetCat) {
          const lowerName = (targetCat.name || '').toLowerCase();
          const related = brands.filter(b => {
            const bCat = categories.find(c => c.id === b.category_id);
            if (!bCat) return false;
            if (lowerName.includes('beer') && bCat.name.toLowerCase().includes('beer')) return true;
            if (lowerName.includes('wine') && bCat.name.toLowerCase().includes('wine')) return true;
            return bCat.product_type === targetCat.product_type;
          });
          if (related.length > 0) brands = related;
        }
      }
    } else if (query.productType) {
      brands = brands.filter(b => categoryIds.includes(b.category_id));
    }

    // 3. Fetch products matching cascade
    let pQuery = supabase.from('products').select(`
      id,
      name,
      product_name,
      category_id,
      brand_id,
      pack_size_id,
      sku,
      pack_type,
      purchase_tp_price,
      mrp_reference,
      status,
      category:categories(id, name, code),
      brand:brands(id, name, brand_name),
      pack_size:pack_sizes(id, name, volume_ml, pack_type)
    `);

    if (query.categoryId) {
      pQuery = pQuery.eq('category_id', query.categoryId);
    } else if (categoryIds.length > 0) {
      pQuery = pQuery.in('category_id', categoryIds);
    }

    if (query.brandId) {
      pQuery = pQuery.eq('brand_id', query.brandId);
    }

    const { data: rawProducts, error: pErr } = await pQuery.order('name');
    if (pErr) throw new Error(`Failed to fetch cascade products: ${pErr.message}`);

    const mappedProducts = (rawProducts || []).map((p: any) => {
      const cat = p.category;
      const b = p.brand;
      const ps = p.pack_size;
      const pType = cat?.product_type || this.resolveProductType(cat?.name || '');
      const variant = p.variant || p.product_name || p.name || 'Standard';
      const vol = ps?.volume_ml ? Number(ps.volume_ml) : undefined;
      const pTypePkg = p.pack_type || 'Bottle';
      const mrpValue = Number(p.mrp_reference || p.mrp || 0);
      const tpPrice = Number(p.purchase_tp_price || 0);

      return {
        id: p.id,
        name: p.name,
        productName: p.product_name || p.name,
        product_name: p.product_name || p.name,
        variant,
        brandId: p.brand_id,
        brand_id: p.brand_id,
        brandName: b?.brand_name || b?.name || '',
        categoryId: p.category_id,
        category_id: p.category_id,
        categoryName: cat?.name || '',
        productType: pType,
        packSizeId: p.pack_size_id,
        pack_size_id: p.pack_size_id,
        volumeMl: vol,
        volume_ml: vol,
        packType: pTypePkg,
        pack_type: pTypePkg,
        mrp: mrpValue,
        mrp_reference: mrpValue,
        purchasePrice: tpPrice,
        purchase_tp_price: tpPrice,
        sku: p.sku,
        status: p.status || 'Active',
      };
    });

    // 4. Extract distinct variants, pack sizes, packaging types
    const variantSet = new Set<string>();
    const packSizeMap = new Map<string, any>();
    const packagingSet = new Set<string>();

    mappedProducts.forEach(p => {
      if (p.variant) variantSet.add(p.variant);
      if (p.packSizeId) {
        packSizeMap.set(p.packSizeId, {
          id: p.packSizeId,
          name: `${p.volumeMl || ''} ml`,
          volumeMl: p.volumeMl || 0,
          packType: p.packType,
        });
      }
      if (p.packType) packagingSet.add(p.packType);
    });

    // Fallback: If pack sizes are empty, load standard sizes from pack_sizes table
    if (packSizeMap.size === 0) {
      let psQuery = supabase.from('pack_sizes').select('id, name, volume_ml, pack_type, category_id').eq('active', true);
      if (query.categoryId) {
        psQuery = psQuery.eq('category_id', query.categoryId);
      }
      const { data: dbPackSizes } = await psQuery.order('volume_ml');
      (dbPackSizes || []).forEach((ps: any) => {
        packSizeMap.set(ps.id, {
          id: ps.id,
          name: ps.name || `${ps.volume_ml} ml`,
          volumeMl: Number(ps.volume_ml) || 0,
          packType: ps.pack_type || 'Bottle',
        });
        if (ps.pack_type) packagingSet.add(ps.pack_type);
      });
    }

    // Fallback: If variants are empty for selected brand, provide standard default variants
    if (variantSet.size === 0 && query.brandId) {
      variantSet.add('Original');
      variantSet.add('Classic');
      variantSet.add('Standard');
    }

    return {
      productTypes: CANONICAL_PRODUCT_TYPES,
      categories: filteredCategories.map(c => ({ id: c.id, name: c.name, productType: c.product_type, code: c.code })),
      brands: brands.map(b => ({ id: b.id, name: b.name, categoryId: b.category_id, category_id: b.category_id })),
      variants: Array.from(variantSet).sort(),
      packSizes: Array.from(packSizeMap.values()).sort((a, b) => a.volumeMl - b.volumeMl),
      packagingTypes: Array.from(packagingSet).sort(),
      products: mappedProducts,
    };
  }

  /**
   * Validate Combination (Section 18)
   */
  static async validateCombination(input: {
    categoryId: string;
    brandId: string;
    packSizeId: string;
    variant?: string;
    packType?: string;
  }): Promise<{ isValid: boolean; error?: string }> {
    const supabase = getSupabaseServiceClient();

    // 1. Check category
    const { data: cat } = await supabase.from('categories').select('id, name, code, product_type').eq('id', input.categoryId).maybeSingle();
    if (!cat) return { isValid: false, error: 'Category does not exist.' };

    const productType = cat.product_type || this.resolveProductType(cat.name);

    // 2. Check brand
    const { data: brand } = await supabase.from('brands').select('id, name, brand_name, category_id').eq('id', input.brandId).maybeSingle();
    if (!brand) return { isValid: false, error: 'Brand does not exist.' };

    if (brand.category_id !== input.categoryId) {
      return {
        isValid: false,
        error: `Brand "${brand.brand_name || brand.name}" does not belong to Category "${cat.name}". Impossible combination rejected.`,
      };
    }

    // 3. Check pack size
    const { data: packSize } = await supabase.from('pack_sizes').select('id, name, volume_ml, pack_type').eq('id', input.packSizeId).maybeSingle();
    if (!packSize) return { isValid: false, error: 'Pack Size does not exist.' };

    const vol = Number(packSize.volume_ml);
    const isWhisky = cat.name.toLowerCase().includes('whisky') || cat.name.toLowerCase().includes('whiskey');

    try {
      this.validateBottleSize(productType, vol, isWhisky);
    } catch (err: any) {
      return { isValid: false, error: err.message };
    }

    return { isValid: true };
  }

  /**
   * Check if a product is active before allowing it in an operational transaction
   */
  static async assertProductActiveForTransaction(productId: string): Promise<void> {
    const supabase = getSupabaseServiceClient();
    const { data: prod, error } = await supabase.from('products').select('id, name, status').eq('id', productId).maybeSingle();

    if (error || !prod) {
      throw new Error(`Product ${productId} not found.`);
    }

    if (prod.status && prod.status !== 'Active') {
      throw new Error(`Product "${prod.name}" is Inactive and cannot be used in a new operational transaction.`);
    }
  }

  /**
   * Excel Import Foundation (Section 19)
   * Validates structure, headers, mappings, duplicates, and row integrity without destructive operations.
   */
  static async validateImportBatch(rows: any[]): Promise<{
    totalRows: number;
    uniqueBrandsCount: number;
    categoriesDetected: Record<string, number>;
    newScmMappingsCount: number;
    duplicateRowsCount: number;
    rowsRequiringReviewCount: number;
    validCount: number;
    errorCount: number;
    errors: Array<{ rowNumber: number; reason: string }>;
    preview: any[];
  }> {
    const { detectCategoryFromProductName, detectBrand } = await import('../../utils/importUtils.js');

    const errors: Array<{ rowNumber: number; reason: string }> = [];
    const preview: any[] = [];
    const brandSet = new Set<string>();
    const categoriesDetected: Record<string, number> = {};
    let newScmMappingsCount = 0;
    let duplicateRowsCount = 0;
    let rowsRequiringReviewCount = 0;

    const seenScmAndProduct = new Set<string>();

    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const rowNum = i + 1;

      const rawProductName = r.product_name || r.name || r['Brand Name'] || r.brand_name || '';
      const rawBrandName = r.brand_name || r.brand || r['Brand Name'] || '';
      const scmCode = r.sku || r.scm_code || r['Local Item Code'] || r.local_item_code || '';
      const rawSize = r.size || r.pack_size || r.pack_size_name || r['Size'] || '';

      if (!rawProductName && !rawBrandName && !scmCode) {
        errors.push({ rowNumber: rowNum, reason: 'Missing product name, brand, or SCM code' });
        continue;
      }

      // Detect brand
      const detectedBrand = rawBrandName ? detectBrand(rawProductName, rawBrandName).brand : detectBrand(rawProductName).brand;
      if (detectedBrand) {
        brandSet.add(detectedBrand.toUpperCase());
      }

      // Detect category
      let categoryName = r.category_name || r.category || '';
      let reviewReq = false;
      if (!categoryName) {
        const catRes = detectCategoryFromProductName(rawProductName || detectedBrand, detectedBrand);
        categoryName = catRes.categoryName;
        reviewReq = catRes.categoryReviewRequired;
      } else {
        reviewReq = r.category_review_required === 'YES' || r.category_review_required === true || categoryName === 'Other / Review';
      }

      if (reviewReq) {
        rowsRequiringReviewCount++;
      }

      categoriesDetected[categoryName] = (categoriesDetected[categoryName] || 0) + 1;

      if (scmCode) {
        newScmMappingsCount++;
      }

      const dupKey = `${scmCode}::${detectedBrand.toUpperCase()}::${rawSize}`;
      if (seenScmAndProduct.has(dupKey)) {
        duplicateRowsCount++;
      } else {
        seenScmAndProduct.add(dupKey);
      }

      preview.push({
        rowNumber: rowNum,
        scmCode,
        productName: rawProductName,
        brandName: detectedBrand,
        categoryName,
        size: rawSize,
        categoryReviewRequired: reviewReq,
        status: reviewReq ? 'Review Needed' : 'Valid'
      });
    }

    return {
      totalRows: rows.length,
      uniqueBrandsCount: brandSet.size,
      categoriesDetected,
      newScmMappingsCount,
      duplicateRowsCount,
      rowsRequiringReviewCount,
      validCount: preview.length,
      errorCount: errors.length,
      errors,
      preview: preview.slice(0, 100),
    };
  }

  /**
   * Universal Permanent Master Resolution Engine
   * Batch-resolves or creates categories, brands, pack sizes, products, and SCM codes.
   */
  static async bulkResolveAndCreate(rows: any[]) {
    const supabase = getSupabaseServiceClient();
    const { detectCategoryFromProductName, detectBrand, parseVolumeMl } = await import('../../utils/importUtils.js');

    // 1. Pre-fetch all existing master tables in parallel
    const [dbCategories, dbBrands, dbPackSizes, dbProducts, dbScm] = await Promise.all([
      supabase.from('categories').select('*'),
      supabase.from('brands').select('*'),
      supabase.from('pack_sizes').select('*'),
      supabase.from('products').select('*'),
      supabase.from('scm_codes').select('*').eq('is_active', true),
    ]);

    const normalizeKey = (s: string) => (s || '').toLowerCase().replace(/\s+/g, ' ').trim();

    const catMap = new Map<string, any>();
    (dbCategories.data || []).forEach(c => {
      if (c.name) catMap.set(normalizeKey(c.name), c);
      if (c.code) catMap.set(normalizeKey(c.code), c);
      if (c.id) catMap.set(c.id, c);
    });

    const brandMap = new Map<string, any>();
    (dbBrands.data || []).forEach(b => {
      const bName = (b.name || b.brand_name || '').trim();
      if (bName) {
        brandMap.set(normalizeKey(bName), b);
        if (b.category_id) brandMap.set(`${b.category_id}::${normalizeKey(bName)}`, b);
      }
      if (b.brand_name) {
        brandMap.set(normalizeKey(b.brand_name), b);
        if (b.category_id) brandMap.set(`${b.category_id}::${normalizeKey(b.brand_name)}`, b);
      }
      if (b.id) brandMap.set(b.id, b);
    });

    const packMap = new Map<string, any>();
    (dbPackSizes.data || []).forEach(ps => {
      if (ps.category_id && ps.volume_ml) packMap.set(`${ps.category_id}::${ps.volume_ml}`, ps);
      if (ps.volume_ml) packMap.set(`${ps.volume_ml}`, ps);
      if (ps.id) packMap.set(ps.id, ps);
    });

    const prodMap = new Map<string, any>();
    (dbProducts.data || []).forEach(p => {
      prodMap.set(p.id, p);
      if (p.sku) prodMap.set(p.sku.toLowerCase().trim(), p);
      const nameKey = (p.product_name || p.name || '').toLowerCase().trim();
      if (p.brand_id && p.pack_size_id) {
        prodMap.set(`${p.brand_id}::${p.pack_size_id}::${nameKey}`, p);
        if (!prodMap.has(`${p.brand_id}::${p.pack_size_id}`)) {
          prodMap.set(`${p.brand_id}::${p.pack_size_id}`, p);
        }
      }
    });

    const scmMap = new Map<string, any>();
    (dbScm.data || []).forEach(s => {
      if (s.scm_code) scmMap.set(s.scm_code.toUpperCase().trim(), s);
    });

    // 2. Queued batch inserts
    const newCategoriesToInsert = new Map<string, any>();
    const newBrandsToInsert = new Map<string, any>();
    const newPacksToInsert = new Map<string, any>();

    // Step A: Pre-resolve Categories
    for (const r of rows) {
      const rawProductName = r.itemName || r.productName || r.variant || r.brandName || r['Brand Name'] || r.product_name || r['Item Name'] || r['Product Name'] || '';
      const rawBrandName = r.brandName || r.brand || r['Brand Name'] || r['Brand'] || '';
      
      let catName = (r.categoryName || r.category || r.category_name || r['Category Name'] || r['Category'] || '').trim();
      if (!catName) {
        catName = detectCategoryFromProductName(rawProductName, rawBrandName).categoryName;
      }

      const cleanCatKey = normalizeKey(catName);
      if (cleanCatKey && !catMap.has(cleanCatKey) && !newCategoriesToInsert.has(cleanCatKey)) {
        newCategoriesToInsert.set(cleanCatKey, {
          name: catName,
          code: catName.substring(0, 4).toUpperCase().replace(/[^A-Z]/g, ''),
          active: true,
        });
      }
    }

    if (newCategoriesToInsert.size > 0) {
      const { data: insertedCats } = await supabase
        .from('categories')
        .insert(Array.from(newCategoriesToInsert.values()))
        .select();

      (insertedCats || []).forEach(c => {
        catMap.set(normalizeKey(c.name), c);
        if (c.code) catMap.set(normalizeKey(c.code), c);
        if (c.id) catMap.set(c.id, c);
      });
    }

    // Step B: Pre-resolve Brands & Pack Sizes
    for (const r of rows) {
      const rawProductName = r.itemName || r.productName || r.variant || r.brandName || r['Brand Name'] || r.product_name || r['Item Name'] || r['Product Name'] || '';
      const rawBrandName = r.brandName || r.brand || r['Brand Name'] || r['Brand'] || '';
      const rawSize = r.bottleSize || r.size || r.pack_size || r['Size'] || r['Bottle Size'] || 0;

      const detected = detectBrand(rawProductName, rawBrandName);
      const finalBrandName = (detected.brand || rawBrandName || 'Unknown Brand').trim();
      const cleanBrandKey = normalizeKey(finalBrandName);

      const brandObj = brandMap.get(cleanBrandKey) || brandMap.get(normalizeKey(rawBrandName));

      let catName = (r.categoryName || r.category || r.category_name || '').trim();
      if (!catName && brandObj && brandObj.category_id) {
        const brandCat = catMap.get(brandObj.category_id);
        if (brandCat) catName = brandCat.name;
      }
      if (!catName) catName = detectCategoryFromProductName(rawProductName, rawBrandName).categoryName;

      const catObj = catMap.get(normalizeKey(catName));
      const catId = catObj ? catObj.id : (brandObj ? brandObj.category_id : '');

      if (cleanBrandKey && !brandMap.has(cleanBrandKey) && !newBrandsToInsert.has(cleanBrandKey)) {
        newBrandsToInsert.set(cleanBrandKey, {
          name: finalBrandName,
          brand_name: finalBrandName,
          category_id: catId,
          active: true,
          maharashtra_status: 'Active',
          source: 'Auto-created from Master Resolution Engine',
        });
      }

      const volMl = typeof rawSize === 'number' ? rawSize : parseVolumeMl(rawSize) || 750;
      const packKey = `${catId}::${volMl}`;
      if (catId && !packMap.has(packKey) && !newPacksToInsert.has(packKey)) {
        newPacksToInsert.set(packKey, {
          category_id: catId,
          name: `${volMl} ml`,
          volume_ml: volMl,
          pack_type: r.packaging || 'Bottle',
          active: true,
          source: 'Verified Source: State Excise',
        });
      }
    }

    if (newBrandsToInsert.size > 0) {
      const { data: insertedBrands, error: bErr } = await supabase
        .from('brands')
        .insert(Array.from(newBrandsToInsert.values()))
        .select();

      if (bErr) {
        console.error('Failed to insert new brands:', bErr.message);
      } else if (insertedBrands) {
        insertedBrands.forEach(b => {
          const bName = (b.name || b.brand_name || '').trim();
          if (bName) {
            brandMap.set(normalizeKey(bName), b);
            if (b.category_id) brandMap.set(`${b.category_id}::${normalizeKey(bName)}`, b);
          }
          if (b.brand_name) {
            brandMap.set(normalizeKey(b.brand_name), b);
            if (b.category_id) brandMap.set(`${b.category_id}::${normalizeKey(b.brand_name)}`, b);
          }
          if (b.id) brandMap.set(b.id, b);
        });
      }
    }

    if (newPacksToInsert.size > 0) {
      const { data: insertedPacks, error: pErr } = await supabase
        .from('pack_sizes')
        .insert(Array.from(newPacksToInsert.values()))
        .select();

      if (pErr) {
        console.error('Failed to insert new pack sizes:', pErr.message);
      } else if (insertedPacks) {
        insertedPacks.forEach(ps => {
          if (ps.category_id && ps.volume_ml) packMap.set(`${ps.category_id}::${ps.volume_ml}`, ps);
          if (ps.volume_ml) packMap.set(`${ps.volume_ml}`, ps);
          if (ps.id) packMap.set(ps.id, ps);
        });
      }
    }

    // Step C: Pre-resolve Products
    const newProductsToInsert = new Map<string, any>();
    const productScmQueue: Array<{ scmCode: string; prodKey: string }> = [];

    for (const r of rows) {
      const rawProductName = r.itemName || r.productName || r.variant || r.brandName || r['Brand Name'] || r.product_name || '';
      const rawBrandName = r.brandName || r.brand || r['Brand Name'] || '';
      const rawSize = r.bottleSize || r.size || r.pack_size || r['Size'] || 0;
      const scmCode = (r.scmCode || r.sku || r.scm_code || r['Local Item Code'] || '').toString().trim();

      const detected = detectBrand(rawProductName, rawBrandName);
      const finalBrandName = (detected.brand || rawBrandName || 'Unknown Brand').trim();
      const cleanBrandKey = normalizeKey(finalBrandName);

      const brandObj = brandMap.get(cleanBrandKey) || brandMap.get(normalizeKey(rawBrandName));

      let catName = (r.categoryName || r.category || r.category_name || '').trim();
      if (!catName && brandObj && brandObj.category_id) {
        const brandCat = catMap.get(brandObj.category_id);
        if (brandCat) catName = brandCat.name;
      }
      if (!catName) catName = detectCategoryFromProductName(rawProductName, rawBrandName).categoryName;

      const catObj = catMap.get(normalizeKey(catName));
      const catId = catObj ? catObj.id : (brandObj ? brandObj.category_id : '');
      const brandId = brandObj ? brandObj.id : '';
      const finalCatId = (brandObj && brandObj.category_id) ? brandObj.category_id : catId;

      const volMl = typeof rawSize === 'number' ? rawSize : parseVolumeMl(rawSize) || 750;
      const packObj = (finalCatId ? packMap.get(`${finalCatId}::${volMl}`) : null) || packMap.get(`${volMl}`);
      const packSizeId = packObj ? packObj.id : '';
      const prodCatId = (packObj && packObj.category_id) ? packObj.category_id : finalCatId;

      const prodName = (rawProductName || `${finalBrandName} ${packObj?.name || ''}`).trim();
      const prodNameKey = prodName.toLowerCase().trim();
      const fullProdKey = `${brandId}::${packSizeId}::${prodNameKey}`;

      let existingProd = prodMap.get(fullProdKey);
      if (!existingProd && scmCode) {
        existingProd = prodMap.get(scmCode.toLowerCase().trim());
      }

      if (!existingProd && brandId && packSizeId && !newProductsToInsert.has(fullProdKey)) {
        newProductsToInsert.set(fullProdKey, {
          name: prodName,
          product_name: prodName,
          category_id: prodCatId,
          brand_id: brandId,
          pack_size_id: packSizeId,
          sku: scmCode || null,
          pack_type: r.packaging || packObj?.pack_type || 'Bottle',
          purchase_tp_price: Number(r.purchaseTpPrice || r.purchase_price || r.mrp || 0),
          selling_price: Number(r.mrp || r.selling_price || 0),
          mrp_reference: Number(r.mrp || 0),
          status: 'Active',
          source: 'Verified Source: Universal Master Resolution Engine',
        });
      }

      if (scmCode) {
        productScmQueue.push({ scmCode, prodKey: fullProdKey });
      }
    }

    if (newProductsToInsert.size > 0) {
      const { data: insertedProds, error: prodErr } = await supabase
        .from('products')
        .insert(Array.from(newProductsToInsert.values()))
        .select();

      if (prodErr) {
        console.error('Failed to insert new products:', prodErr.message);
      } else if (insertedProds) {
        insertedProds.forEach(p => {
          prodMap.set(p.id, p);
          if (p.sku) prodMap.set(p.sku.toLowerCase().trim(), p);
          const nameKey = (p.product_name || p.name || '').toLowerCase().trim();
          prodMap.set(`${p.brand_id}::${p.pack_size_id}::${nameKey}`, p);
          prodMap.set(`${p.brand_id}::${p.pack_size_id}`, p);
        });
      }
    }

    // Step D: Batch Insert/Update SCM Codes using resilient ScmService
    const { ScmService } = await import('./scmService.js');
    for (const q of productScmQueue) {
      const cleanScm = q.scmCode.toUpperCase().trim();
      if (!scmMap.has(cleanScm)) {
        const prodObj = prodMap.get(q.prodKey) || 
                        prodMap.get(q.prodKey.split('::').slice(0, 2).join('::')) ||
                        Array.from(prodMap.values()).find(p => p.sku === q.scmCode);
        if (prodObj) {
          try {
            const scmRecord = await ScmService.ensureScmCodeExists(cleanScm, prodObj.id, {
              variant: prodObj.name || prodObj.product_name || 'Original',
              packagingType: prodObj.pack_type || 'Bottle',
              sourceReference: 'Universal Master Resolution Engine',
            });
            scmMap.set(cleanScm, scmRecord);
          } catch (err: any) {
            console.error(`Failed to register SCM code ${cleanScm}:`, err.message);
          }
        }
      }
    }

    // Step E: Return structured resolution results with complete database IDs for dropdown auto-selection
    const results: any[] = rows.map(r => {
      const rawProductName = r.itemName || r.productName || r.variant || r.brandName || r['Brand Name'] || r.product_name || r['Item Name'] || r['Product Name'] || '';
      const rawBrandName = r.brandName || r.brand || r['Brand Name'] || r['Brand'] || '';
      const rawSize = r.bottleSize || r.size || r.pack_size || r['Size'] || r['Bottle Size'] || 0;
      const scmCode = (r.scmCode || r.sku || r.scm_code || r['Local Item Code'] || r['SCM Code'] || '').toString().trim();

      const detected = detectBrand(rawProductName, rawBrandName);
      const finalBrandName = (detected.brand || rawBrandName || 'Unknown Brand').trim();
      const cleanBrandKey = normalizeKey(finalBrandName);

      const brandObj = brandMap.get(cleanBrandKey) || brandMap.get(normalizeKey(rawBrandName));

      const catRes = detectCategoryFromProductName(rawProductName, rawBrandName);
      let catName = (r.categoryName || r.category || catRes.categoryName || '').trim();
      if ((!r.categoryName && !r.category) && brandObj && brandObj.category_id) {
        const brandCat = catMap.get(brandObj.category_id);
        if (brandCat) catName = brandCat.name;
      }

      const catObj = catMap.get(normalizeKey(catName));
      const catId = catObj ? catObj.id : (brandObj ? brandObj.category_id : '');
      const finalCatId = (brandObj && brandObj.category_id) ? brandObj.category_id : catId;

      const volMl = typeof rawSize === 'number' ? rawSize : parseVolumeMl(rawSize) || 750;
      const packObj = (finalCatId ? packMap.get(`${finalCatId}::${volMl}`) : null) || packMap.get(`${volMl}`);
      const prodName = (rawProductName || `${brandObj?.name} ${packObj?.name || ''}`).trim();
      const prodObj = prodMap.get(`${brandObj?.id}::${packObj?.id}::${prodName.toLowerCase().trim()}`) || 
                      (scmCode ? prodMap.get(scmCode.toLowerCase().trim()) : null);

      const isFullyResolved = Boolean(prodObj?.id && brandObj?.id && packObj?.id);

      return {
        ...r,
        matchedProductId: prodObj?.id || '',
        matchedProductName: prodObj?.name || prodName,
        brandId: brandObj?.id || '',
        categoryId: catObj?.id || '',
        packSizeId: packObj?.id || '',
        categoryName: catObj?.name || catRes.categoryName,
        brandName: brandObj?.name || detected.brand || rawBrandName,
        variant: detected.variant || prodName,
        bottleSize: volMl,
        scmCode,
        resolutionStatus: isFullyResolved ? 'Matched' : 'Needs Review',
        status: isFullyResolved ? 'valid' : 'invalid',
        errorMessage: isFullyResolved ? '' : 'Master resolution incomplete: missing catalog relationships.'
      };
    });

    return results;
  }
}
