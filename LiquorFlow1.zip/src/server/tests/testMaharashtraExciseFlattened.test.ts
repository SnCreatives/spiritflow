import { parsePaste } from '../../utils/importUtils.js';

const pastedText = `
Received Date :    Auto T. P. No:T. P. No(Manual):  T.P.Date:   Received From :

District :

 Party :

Validity : 

       

SCM Code Display

SrNoItemNameSizeQty (Cases)Qty (Bottles)Batch NoAuto BatchMfg. MonthMRPB.L.V/v (%)Tot. Bott.1MAGIC MOMENTS PURE GRAIN VODKA .
SCM Code:SCMPL0010663180 ML1.000462BTP16-270926/559Sep-2026280.008.6442.8482MAGIC MOMENTS PURE GRAIN VODKA .
SCM Code:SCMPL003642090 ML (Pet)-960.0024430BTP16-170926/519Sep-2026145.002.1642.8243Real Star Fortified Wine .
SCM Code:SCMWN0027064180 ML1.000947BTWN16-150926/1301Sep-202670.008.6424.0484M2 MAGIC MOMENTS Jamun Spicy Mint VIVID FLAVOURED VODKA .
SCM Code:SCMPL0042888180 ML (Pet)0.0024356BTP16-190826/429Aug-2026270.004.3242.8245M2 MAGIC MOMENTS Jamun Spicy Mint VIVID FLAVOURED VODKA .
SCM Code:SCMPL004288990 ML (Pet)-960.0024343BTP16-130826/414Aug-2026145.002.1642.824 Total 2.0072    25.92 168
`;

const res = parsePaste(pastedText);
console.log('Parsed Rows Count:', res.data.length);
console.log('Parsed Data:', JSON.stringify(res.data, null, 2));
