function extractName(sectionPrev: string) {
  const parts = sectionPrev.split('.');
  const rawName = parts.length >= 2 ? parts[parts.length - 2] : sectionPrev;
  console.log('rawName:', JSON.stringify(rawName));
  const cleanMatch = rawName.match(/([A-Z][A-Za-z0-9\s()\-&]+)/);
  return cleanMatch ? cleanMatch[1].trim() : rawName.trim();
}

console.log('Result 1:', extractName("SrNoItemNameSizeQty (Cases)Qty (Bottles)Batch NoAuto BatchMfg. MonthMRPB.L.V/v (%)Tot. Bott.1MAGIC MOMENTS PURE GRAIN VODKA ."));
console.log('Result 2:', extractName("SCMPL0010663180 ML1.000462BTP16-270926/559Sep-2026280.008.6442.8482MAGIC MOMENTS PURE GRAIN VODKA ."));
console.log('Result 3:', extractName("SCMPL003642090 ML (Pet)-960.0024430BTP16-170926/519Sep-2026145.002.1642.8243Real Star Fortified Wine ."));
console.log('Result 4:', extractName("SCMWN0027064180 ML1.000947BTWN16-150926/1301Sep-202670.008.6424.0484M2 MAGIC MOMENTS Jamun Spicy Mint VIVID FLAVOURED VODKA ."));
console.log('Result 5:', extractName("SCMPL0042888180 ML (Pet)0.0024356BTP16-190826/429Aug-2026270.004.3242.8245M2 MAGIC MOMENTS Jamun Spicy Mint VIVID FLAVOURED VODKA ."));
