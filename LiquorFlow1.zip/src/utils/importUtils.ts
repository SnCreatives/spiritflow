import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { CANONICAL_BRAND_MASTER } from './canonicalBrands';

export type ImportModule = 
  | 'products' 
  | 'brands' 
  | 'categories'
  | 'pack-sizes' 
  | 'opening-stock' 
  | 'purchases' 
  | 'adjustments';

/**
 * Detects the brand from a given item name or brand name string using canonical master.
 * Returns the best matching brand name from master, or extracts the first word(s) as a candidate.
 */
export function detectBrand(itemName: string, brandName?: string): { brand: string; variant: string } {
  const cleanBrandName = (brandName || '').trim();
  const cleanItemName = (itemName || '').trim();
  const fullText = `${cleanBrandName} ${cleanItemName}`.trim();
  const normalizedText = fullText.toLowerCase();

  // 1. If explicit brandName provided and non-empty, use explicit brandName first without stripping brand words
  if (cleanBrandName) {
    let variant = cleanItemName;
    if (variant.toLowerCase().startsWith(cleanBrandName.toLowerCase())) {
      variant = variant.substring(cleanBrandName.length).trim().replace(/^[:\-\s,.]+/, '').trim();
    }
    return { brand: cleanBrandName, variant: variant || 'Original' };
  }

  // 2. Check if matches canonical brand master
  let bestCanonicalMatch = '';
  let longestMatchLength = 0;

  for (const categoryBrands of Object.values(CANONICAL_BRAND_MASTER)) {
    for (const b of categoryBrands) {
      const nb = b.toLowerCase();
      const regex = new RegExp(`\\b${nb.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
      if (regex.test(normalizedText)) {
        if (b.length > longestMatchLength) {
          bestCanonicalMatch = b;
          longestMatchLength = b.length;
        }
      }
    }
  }

  if (bestCanonicalMatch) {
    const regex = new RegExp(`\\b${bestCanonicalMatch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    let variant = cleanItemName ? cleanItemName.replace(regex, '').trim() : fullText.replace(regex, '').trim();
    variant = variant.replace(/^[:\-\s,.]+/, '').trim();
    return { brand: bestCanonicalMatch, variant: variant || 'Original' };
  }

  // 3. Fallback: derive brand from itemName
  // Check for category keyword splitting
  const catMatch = cleanItemName.match(/^(.*?)\s+\b(whisky|whiskey|beer|wine|rum|vodka|gin|brandy|tequila|liqueur|country\s*liquor)\b(.*)$/i);
  if (catMatch && catMatch[1] && catMatch[1].trim()) {
    const derivedBrand = catMatch[1].trim();
    const derivedVariant = `${catMatch[2] || ''} ${catMatch[3] || ''}`.trim();
    return { brand: derivedBrand, variant: derivedVariant || 'Original' };
  }

  // Fallback to taking leading words
  const words = cleanItemName.split(/\s+/).filter(Boolean);
  if (words.length > 0) {
    if (words.length <= 3) {
      return { brand: cleanItemName, variant: 'Original' };
    }
    const candidateBrand = words.slice(0, 2).join(' ');
    const variant = words.slice(2).join(' ');
    return { brand: candidateBrand, variant: variant || 'Original' };
  }

  return { brand: cleanItemName || 'Unknown Brand', variant: 'Original' };
}

export interface ColumnMapping {
  [key: string]: string; // csvHeader -> fieldKey
}

export const FIELD_ALIASES: { [key: string]: string[] } = {
  product_name: ['product name', 'product_name', 'product', 'item name', 'item', 'name', 'itemname', 'description', 'variant', 'variant name'],
  brand_name: ['brand', 'brand name', 'brand_name', 'brandname', 'manufacturer'],
  category_name: ['category', 'category name', 'category_name', 'categoryname', 'product type'],
  pack_size_name: ['pack size', 'packsize', 'volume', 'size', 'bottle size', 'pack_size'],
  quantity: ['qty', 'quantity', 'stock', 'opening qty', 'opening quantity', 'units'],
  qty_cases: ['qty (cases)', 'qty cases', 'cases', 'cases qty', 'quantity(case)', 'quantity (case)'],
  qty_bottles: ['qty (bottles)', 'qty bottles', 'bottles', 'bottles qty', 'quantity(loose bottle)', 'quantity (loose bottle)'],
  total_bottles: ['tot. bott.', 'tot. bott', 'tot bott', 'total bottles', 'tot.bott.', 'tot.bott', 'total qty'],
  sku: ['sku', 'code', 'product code', 'item code', 'scm code', 'scm', 'scmcode', 'excise code', 'local item code', 'local_item_code'],
  purchase_price: ['purchase price', 'tp price', 'tp', 'cost', 'buy price', 'purchase_tp_price'],
  selling_price: ['selling price', 'sale price', 'retail price'],
  mrp: ['mrp', 'max retail price', 'maximum retail price', 'price'],
  batch_number: ['batch', 'batch number', 'batch no', 'batch no.', 'lot number', 'lot'],
  auto_batch: ['auto batch', 'autobatch'],
  mfg_month: ['mfg. month', 'mfg month', 'mfg date', 'manufacturing month'],
  bulk_litres: ['b.l.', 'b.l', 'bl', 'bulk litres', 'bulk litre'],
  strength: ['v/v (%)', 'v/v%', 'v/v', 'strength', 'abv'],
  remarks: ['remarks', 'notes', 'comments', 'description'],
  status: ['status', 'active', 'state'],
  purchase_number: ['purchase number', 'invoice number', 'bill number', 'purchase no', 'ref no'],
  purchase_date: ['date', 'purchase date', 'invoice date', 'bill date', 'sale date'],
  adjustment_type: ['type', 'adjustment type', 'movement type'],
};

/**
 * Dynamically detects category from product name using keyword patterns.
 * Returns category name, code, and whether manual review is required.
 */
export function detectCategoryFromProductName(
  productName: string,
  brandName?: string
): { categoryName: string; categoryCode: string; categoryReviewRequired: boolean } {
  const text = `${brandName || ''} ${productName || ''}`.trim();
  const lower = text.toLowerCase();

  // 1. Whisky
  if (/\b(whisky|whiskey|scotch|single\s*malt|blended\s*grain|blended\s*scotch|bourbon|fine\s*grain|irish\s*blend)\b/i.test(lower) && !/\b(whiksy)\b/i.test(lower)) {
    return { categoryName: 'Whisky', categoryCode: 'WHISKY', categoryReviewRequired: false };
  }
  // 2. Beer
  if (/\b(beer|lager|pilsner|stout|ale|draught|super\s*strong\s*beer|super\s*premium\s*beer|king\s*of\s*beer|strong\s*beer)\b/i.test(lower)) {
    return { categoryName: 'Beer', categoryCode: 'BEER', categoryReviewRequired: false };
  }
  // 3. Wine
  if (/\b(wine|zinfandel|rose\s*wine|shiraz|cabernet|merlot|chardonnay|sparkling\s*wine|port\s*wine|pinot|chenin|fortified\s*wine|muscat|sauvignon|fruzzante|frizzano|porto|rioja)\b/i.test(lower)) {
    return { categoryName: 'Wine', categoryCode: 'WINE', categoryReviewRequired: false };
  }
  // 4. Rum
  if (/\b(rum|xxx|vatted\s*rum|white\s*rum|dark\s*rum|matured\s*rum|spiced\s*rum)\b/i.test(lower)) {
    return { categoryName: 'Rum', categoryCode: 'RUM', categoryReviewRequired: false };
  }
  // 5. Vodka
  if (/\b(vodka)\b/i.test(lower)) {
    return { categoryName: 'Vodka', categoryCode: 'VODKA', categoryReviewRequired: false };
  }
  // 6. Gin
  if (/\b(gin)\b/i.test(lower)) {
    return { categoryName: 'Gin', categoryCode: 'GIN', categoryReviewRequired: false };
  }
  // 7. Brandy
  if (/\b(brandy|xo\b)/i.test(lower)) {
    return { categoryName: 'Brandy', categoryCode: 'BRANDY', categoryReviewRequired: false };
  }
  // 8. Tequila
  if (/\b(tequila)\b/i.test(lower)) {
    return { categoryName: 'Tequila', categoryCode: 'TEQUILA', categoryReviewRequired: false };
  }
  // 9. Liqueur
  if (/\b(liqueur)\b/i.test(lower)) {
    return { categoryName: 'Liqueur', categoryCode: 'LIQUEUR', categoryReviewRequired: false };
  }
  // 10. Country Liquor
  if (/\b(country\s*liquor|desi)\b/i.test(lower)) {
    return { categoryName: 'Country Liquor', categoryCode: 'COUNTRY_LIQUOR', categoryReviewRequired: false };
  }

  // Fallback for unrecognized/uncertain entries
  return { categoryName: 'Other / Review', categoryCode: 'OTHER_REVIEW', categoryReviewRequired: true };
}

export function autoMapColumns(headers: string[], fieldKeys: string[] = Object.keys(FIELD_ALIASES)): ColumnMapping {
  const mapping: ColumnMapping = {};
  const keys = fieldKeys && fieldKeys.length > 0 ? fieldKeys : Object.keys(FIELD_ALIASES);
  
  headers.forEach(header => {
    const normalizedHeader = header.toLowerCase().trim().replace(/_/g, ' ');
    
    // Exact match first
    const exactMatch = keys.find(key => key.toLowerCase() === normalizedHeader.replace(/ /g, '_'));
    if (exactMatch) {
      mapping[header] = exactMatch;
      return;
    }

    // Alias match
    for (const [key, aliases] of Object.entries(FIELD_ALIASES)) {
      if (keys.includes(key) && aliases.includes(normalizedHeader)) {
        mapping[header] = key;
        break;
      }
    }
  });

  return mapping;
}

export async function parseCsv(file: File): Promise<{ headers: string[], data: any[] }> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        resolve({
          headers: results.meta.fields || [],
          data: results.data
        });
      },
      error: (err) => reject(err)
    });
  });
}

export async function parseExcel(file: File): Promise<{ [sheetName: string]: { headers: string[], data: any[] } }> {
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data);
  const result: { [sheetName: string]: { headers: string[], data: any[] } } = {};

  workbook.SheetNames.forEach(name => {
    const sheet = workbook.Sheets[name];
    const jsonData = XLSX.utils.sheet_to_json(sheet) as any[];
    const headers = jsonData.length > 0 ? Object.keys(jsonData[0]) : [];
    result[name] = { headers, data: jsonData };
  });

  return result;
}

export interface ParsedDocumentResult {
  headers: string[];
  data: any[];
  metadata?: {
    receivedDate?: string;
    autoTpNo?: string;
    manualTpNo?: string;
    tpDate?: string;
    receivedFrom?: string;
    district?: string;
    party?: string;
    validityDate?: string;
  };
}

/**
 * Robust clipboard parser for tabular data copied from Excel, Google Sheets,
 * and excise portal/PDF reports with line wrapping.
 * 
 * Rules:
 * 1. Parse tab-separated, pipe-separated or column-aligned data using actual delimiters and header positions.
 * 2. Continuation lines for a wrapped logical row are merged into the same product row.
 * 3. Detect new product rows using sequence number ("SrNo") or complete row boundaries.
 * 4. "SCM Code:..." lines must NOT become separate product rows; they are continuation data.
 * 5. Summary / footer rows (e.g. "Total 14.000", "Grand Total") are excluded.
 * 6. Preserves all 12 canonical fields.
 * 7. Extracts header metadata (Received Date, Auto TP No, Party, etc.) if pasted as full document.
 */
export function parsePaste(text: string): ParsedDocumentResult {
  const metadata: any = {};
  if (!text || typeof text !== 'string') {
    return { headers: [], data: [], metadata };
  }

  const extractMetaField = (keyPattern: string): string => {
    const regex = new RegExp(`${keyPattern}\\s*:\\s*(.*?)(?=(?:Received\\s*Date|Auto\\s*T\\.?\\s*P\\.?\\s*No|T\\.?\\s*P\\.?\\s*No\\s*\\(Manual\\)|T\\.?P\\.?\\s*Date|Received\\s*From|District|Party|Validity)\\s*:|SCM\\s*Code\\s*Display|\\r|\\n|$)`, 'i');
    const match = text.match(regex);
    return match ? match[1].replace(/\s+/g, ' ').trim() : '';
  };

  metadata.receivedDate = extractMetaField('Received\\s*Date');
  metadata.autoTpNo = extractMetaField('Auto\\s*T\\.?\\s*P\\.?\\s*No');
  metadata.manualTpNo = extractMetaField('T\\.?\\s*P\\.?\\s*No\\s*\\(Manual\\)');
  metadata.tpDate = extractMetaField('T\\.?\\s*P\\.?\\s*Date');
  metadata.receivedFrom = extractMetaField('Received\\s*From');
  metadata.district = extractMetaField('District');
  metadata.party = extractMetaField('Party');
  metadata.validityDate = extractMetaField('Validity(?:\\s*Date)?');

  // Dedicated Maharashtra Excise Received-From-Trader format detector and parser
  const isMaharashtraExcise = /SCM\s*Code\s*Display/i.test(text) || /SCM\s*Code\s*:/i.test(text);

  if (isMaharashtraExcise) {
    const dataRows: any[] = [];
    const lines = text.split(/\r?\n/).map(l => l.replace(/[\u00a0\u200b\u2007\u2008\u2009]/g, ' ').replace(/\s+/g, ' ').trim()).filter(Boolean);
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const scmMatch = line.match(/SCM\s*Code\s*:\s*(SCM[A-Za-z]{2}\d{7})/i);
      
      if (scmMatch) {
        const scmCode = scmMatch[1].toUpperCase();
        
        let itemName = '';
        for (let j = i - 1; j >= 0; j--) {
          const prevLine = lines[j];
          if (
            !/:/i.test(prevLine) &&
            !/^(total|grand\s*total|sub\s*total|subtotal|summary|page\s*\d+|net\s*total)\b/i.test(prevLine) &&
            !/\d+\s*ML/i.test(prevLine)
          ) {
            let cleanedPrev = prevLine;
            // Strip flattened header line prefix if present
            if (/SrNoItemName/i.test(cleanedPrev) || /Sr\s*No\s*Item\s*Name/i.test(cleanedPrev)) {
              cleanedPrev = cleanedPrev.replace(/^Sr\s*No\s*Item\s*Name\s*Size.*?Tot\.\s*Bott\./i, '').trim();
            }
            itemName = cleanedPrev.replace(/^\d+/, '').replace(/\s*\.$/, '').trim();
            break;
          }
        }
        
        const metricsPartOnSameLine = line.substring(line.indexOf(scmMatch[0]) + scmMatch[0].length).trim();
        const sizeRegex = /^(\d+\s*ML(?:\s*\([^)]+\))?)/i;
        
        if (sizeRegex.test(metricsPartOnSameLine)) {
          // FLATTENED FORMAT (COLLAPSED LINES)
          const sizeMatch = metricsPartOnSameLine.match(sizeRegex);
          if (sizeMatch) {
            const size = sizeMatch[1].trim();
            let remaining = metricsPartOnSameLine.substring(sizeMatch[0].length).trim();
            
            // Limit size factor match to 1 or 2 digits to prevent eating into the cases decimal quantity
            const sizeFactorMatch = remaining.match(/^-\d{1,2}/);
            if (sizeFactorMatch) {
              remaining = remaining.substring(sizeFactorMatch[0].length).trim();
            }
            
            // Distinguish between 2-decimal zero cases and 3-decimal non-zero cases
            const midRegex = /^((?:0\.\d{2})|(?:\d+\.\d{3}))(\d+)(BT[A-Z0-9_\-/]+?)(?=(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-\d{4})/i;
            const midMatch = remaining.match(midRegex);
            
            if (midMatch) {
              const qtyCases = midMatch[1];
              const bottlesAndAutoBatch = midMatch[2];
              const batchNo = midMatch[3].trim();
              
              let remainingMetrics = remaining.substring(midMatch[0].length).trim();
              const metricsRegex = /^([A-Za-z]{3}-\d{4})(\d+\.\d{2})(\d+\.\d{2})(\d+\.\d{1})(\d+)/i;
              const metMatch = remainingMetrics.match(metricsRegex);
              
              if (metMatch) {
                const mfgMonth = metMatch[1].trim();
                const mrp = metMatch[2];
                const bl = metMatch[3];
                const vv = metMatch[4];
                const totBott = metMatch[5];
                
                let qtyBottles = '0';
                if (qtyCases.startsWith('0.00') && bottlesAndAutoBatch.length >= 5) {
                  qtyBottles = bottlesAndAutoBatch.substring(0, 2);
                }
                
                dataRows.push({
                  'Item Name': itemName,
                  'SCM Code': scmCode,
                  'Size': size,
                  'Qty (Cases)': qtyCases,
                  'Qty (Bottles)': qtyBottles,
                  'Batch No': batchNo,
                  'Mfg. Month': mfgMonth,
                  'MRP': mrp,
                  'B.L.': bl,
                  'V/v (%)': vv,
                  'Tot. Bott.': totBott
                });
              }
            }
          }
        } else {
          // REGULAR FORMAT (SEPARATED LINES)
          let metricsLine = '';
          const metricsRegex = /^(\d+\s*ML(?:\s*\([^)]+\))?)\s+(\d+(?:\.\d+)?)\s+(\d+)\s+(\d+)\s+(\S+)\s+([A-Za-z]{3}-\d{4})\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s+(\d+)/i;
          
          for (let k = i + 1; k < Math.min(lines.length, i + 4); k++) {
            const nextLine = lines[k];
            if (metricsRegex.test(nextLine)) {
              metricsLine = nextLine;
              break;
            }
          }
          
          if (itemName && metricsLine) {
            const m = metricsLine.match(metricsRegex);
            if (m) {
              dataRows.push({
                'Item Name': itemName,
                'SCM Code': scmCode,
                'Size': m[1].trim(),
                'Qty (Cases)': m[2],
                'Qty (Bottles)': m[4],
                'Batch No': m[5].trim(),
                'Mfg. Month': m[6].trim(),
                'MRP': m[7],
                'B.L.': m[8],
                'V/v (%)': m[9],
                'Tot. Bott.': m[10]
              });
            }
          }
        }
      }
    }
    
    if (dataRows.length > 0) {
      return {
        headers: [
          'Item Name',
          'SCM Code',
          'Size',
          'Qty (Cases)',
          'Qty (Bottles)',
          'Batch No',
          'Mfg. Month',
          'MRP',
          'B.L.',
          'V/v (%)',
          'Tot. Bott.'
        ],
        data: dataRows,
        metadata
      };
    }
  }

  const rawLines = text.split(/\r?\n/);
  const nonEmptyLines: string[] = [];

  for (const line of rawLines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    // Exclude summary / footer rows from candidate lines
    if (/^(total|grand\s*total|sub\s*total|subtotal|summary|page\s*\d+|net\s*total)\b/i.test(trimmed)) {
      continue;
    }
    nonEmptyLines.push(trimmed);
  }

  if (nonEmptyLines.length === 0) return { headers: [], data: [], metadata };

  // Find the table header line index
  let headerIndex = -1;
  for (let i = 0; i < nonEmptyLines.length; i++) {
    const l = nonEmptyLines[i].toLowerCase();
    const isHeaderCandidate =
      (l.includes('srno') || l.includes('sr.no') || l.includes('sr no') || l.includes('s.no') || l.includes('s no') || l.includes('#')) &&
      (l.includes('item') || l.includes('product') || l.includes('brand') || l.includes('variant') || l.includes('size') || l.includes('qty'));
    if (isHeaderCandidate) {
      headerIndex = i;
      break;
    }
  }

  if (headerIndex === -1) {
    // If no header row with SrNo found, check if line has columns (tab or pipe)
    for (let i = 0; i < nonEmptyLines.length; i++) {
      const l = nonEmptyLines[i].toLowerCase();
      if ((l.includes('item') || l.includes('product') || l.includes('size') || l.includes('qty') || l.includes('tp')) && (l.includes('\t') || l.includes('|'))) {
        headerIndex = i;
        break;
      }
    }
  }

  if (headerIndex === -1) headerIndex = 0;

  const headerLine = nonEmptyLines[headerIndex];
  const usePipe = headerLine.includes('|');
  const useTab = headerLine.includes('\t');

  const splitCells = (l: string): string[] => {
    if (usePipe) {
      return l.split('|').map(c => c.trim()).filter((c, idx, arr) => !(idx === 0 && c === '') && !(idx === arr.length - 1 && c === ''));
    }
    if (useTab) {
      return l.split('\t').map(c => c.trim());
    }
    return l.split(/\s{2,}/).map(c => c.trim());
  };

  const headers = splitCells(headerLine);
  const hasSrNo = /^sr\.?\s*no|^s\.?\s*no|^#$/i.test(headers[0] || '');

  const dataRows: any[] = [];
  let currentRow: any = null;
  let nextExpectedSr = 1;

  for (let i = headerIndex + 1; i < nonEmptyLines.length; i++) {
    const line = nonEmptyLines[i];
    const cells = splitCells(line);
    if (cells.length === 0 || (cells.length === 1 && !cells[0])) continue;

    // Check if line represents a summary / footer row
    if (/^(total|grand\s*total|sub\s*total|subtotal|summary|page\s*\d+|net\s*total)\b/i.test(cells[0])) {
      continue;
    }

    const firstCell = cells[0];
    const isIntegerSr = /^\d+$/.test(firstCell);
    const parsedSr = isIntegerSr ? parseInt(firstCell, 10) : -1;

    // Check if line represents a NEW product row
    let isNewRow = false;
    if (hasSrNo) {
      if (
        isIntegerSr &&
        (parsedSr === 1 ||
          parsedSr === nextExpectedSr ||
          (currentRow && parsedSr === parseInt(currentRow['SrNo'] || '0', 10) + 1))
      ) {
        isNewRow = true;
      }
    } else {
      // If table lacks SrNo column, line is a new row if column count is close to header length
      // and first column does not look like SCM continuation or purely decimal wrap
      if (
        cells.length >= headers.length - 2 &&
        !/^(scm\s*code|scm)/i.test(firstCell) &&
        !/^\d+(\.\d+)?$/.test(firstCell)
      ) {
        isNewRow = true;
      }
    }

    if (isNewRow) {
      if (currentRow) {
        finalizeLogicalRow(currentRow);
        dataRows.push(currentRow);
      }
      currentRow = {};
      nextExpectedSr = parsedSr + 1;

      headers.forEach((h, idx) => {
        if (cells[idx] !== undefined && cells[idx] !== '') {
          currentRow[h] = cells[idx];
        }
      });
    } else if (currentRow) {
      // Continuation line for currentRow:
      // 1. SCM Code extraction
      const scmMatch = cells.find(c => /scm\s*code/i.test(c)) || (cells[0] && /scm/i.test(cells[0]) ? cells[0] : null);
      if (scmMatch) {
        const extractedScm = scmMatch.match(/(?:scm\s*code\s*[:\-\s]?\s*|scm\s*[:\-\s]?\s*)([a-z0-9_\-]+)/i);
        if (extractedScm) {
          currentRow['SCM Code'] = extractedScm[1];
        } else {
          currentRow['SCM Code'] = scmMatch;
        }
      }

      // 2. Map cells to remaining unpopulated headers
      const startsWithScm = /scm\s*code/i.test(cells[0]);
      const startHeaderOffset = startsWithScm ? 2 : 1;

      for (let hIdx = startHeaderOffset; hIdx < headers.length; hIdx++) {
        const headerName = headers[hIdx];
        const cellVal = cells[startsWithScm ? hIdx - 1 : hIdx];
        if (cellVal !== undefined && cellVal !== '' && !currentRow[headerName]) {
          currentRow[headerName] = cellVal;
        }
      }

      // 3. Fallback cell extraction for essential fields if still missing
      cells.forEach(c => {
        if (/^\d+\s*(ml|l)(\s*\(\d+\))?$/i.test(c) && !currentRow['Size']) {
          currentRow['Size'] = c;
        }
      });
    }
  }

  if (currentRow) {
    finalizeLogicalRow(currentRow);
    dataRows.push(currentRow);
  }

  return { headers, data: dataRows, metadata };
}

/**
 * Clean and normalize a logical row after parsing continuation lines
 */
function finalizeLogicalRow(row: any) {
  // If ItemName contains SCM Code, extract SCM Code and clean ItemName
  const itemNameKey = Object.keys(row).find(k => /^(item\s*name|item|product\s*name|product)/i.test(k));
  if (itemNameKey && row[itemNameKey]) {
    const val = String(row[itemNameKey]);
    const scmInItem = val.match(/(?:scm\s*code\s*[:\-\s]\s*|scm\s*[:\-\s]\s*)([a-z0-9_\-]+)/i);
    if (scmInItem) {
      if (!row['SCM Code']) {
        row['SCM Code'] = scmInItem[1];
      }
      row[itemNameKey] = val.replace(/(?:scm\s*code\s*[:\-\s]\s*|scm\s*[:\-\s]\s*)[a-z0-9_\-]+/i, '').trim();
    }
  }

  // Ensure normalized SCM Code field
  if (row['SCM Code']) {
    const val = String(row['SCM Code']).trim();
    const scmClean = val.match(/(?:scm\s*code\s*[:\-\s]\s*|scm\s*[:\-\s]\s*)([a-z0-9_\-]+)/i);
    if (scmClean && scmClean[1]) {
      row['SCM Code'] = scmClean[1];
    } else {
      row['SCM Code'] = val;
    }
  }
}

/**
 * Parse numeric volume in ML from various string formats (e.g. "650 ML", "650ml", "650 ml Pint")
 */
export function parseVolumeMl(val: any): number {
  if (!val) return 0;
  if (typeof val === 'number') return val;
  const str = String(val).trim();
  const match = str.match(/(\d+)\s*(?:ml|l)?/i);
  return match ? parseInt(match[1], 10) : 0;
}

const GENERIC_STOP_WORDS = new Set([
  'whisky', 'whiskey', 'beer', 'rum', 'vodka', 'gin', 'brandy', 'wine',
  'liquor', 'spirit', 'beverage', 'bottle', 'can', 'pint', 'ml',
  'international', 'premium', 'deluxe', 'special', 'classic', 'original', 'super'
]);

/**
 * Standardized interface for a resolved canonical product
 */
export interface ResolvedProduct {
  productId: string;
  brandId: string;
  variantId?: string; // variant_id if available, otherwise variant name
  categoryId: string;
  packSizeId: string;
  packagingTypeId?: string;
  scmMasterId?: string;
  
  productName: string;
  brandName: string;
  categoryName: string;
  variant: string;
  volumeMl: number;
  packType: string;
  sku: string;
  mrp: number;
  purchasePrice: number;
  
  score: number;
  matchType: 'scm' | 'id' | 'product_size' | 'brand_variant_size' | 'name_size' | 'partial';
  isAmbiguous?: boolean;
  isConflict?: boolean;
  isNewMaster?: boolean;
  potentialMatches?: ResolvedProduct[];
  errorMessage?: string;
  resolutionMethod?: string;
  scmCode?: string;
  scmLookupFound?: boolean;
  bottleSizeId?: string;
  resolutionStatus?: 'RESOLVED' | 'UNRESOLVED' | 'NEW_MASTER';
}

/**
 * Normalizes strings for robust matching
 */
/**
 * Normalizes strings for robust matching
 * Removes common punctuation, trailing dots, and standard size patterns (e.g. " (750ml)")
 */
function normalizeForMatch(str: any): string {
  if (!str) return '';
  return String(str)
    .toLowerCase()
    .trim()
    .replace(/\s*\(\d+\s*ml\)\s*/gi, ' ') // remove "(750ml)" patterns
    .replace(/\s*\d+\s*ml\s*/gi, ' ')     // remove "750ml" patterns
    .replace(/[.\-_,]/g, ' ')             // replace common separators with space
    .replace(/\s+/g, ' ')                  // collapse multiple spaces
    .trim();
}

/**
 * Canonical product resolution against existing catalog items:
 * Priority:
 * 1. Exact SCM Code
 * 2. Exact canonical Product ID, if available
 * 3. Product Name + Bottle Size (Canonical Match)
 * 4. Brand + Variant + Bottle Size
 * 5. Fuzzy Item Name Match + Bottle Size
 * 
 * Strict: Never creates new records; resolves only against existing database items.
 */
function cleanScmCode(str: any): string {
  if (!str) return '';
  return String(str).toLowerCase().trim().replace(/[^a-z0-9]/g, '');
}

function isBrandCompatible(pBrandName: string, pastedItemName: string, pastedBrandName?: string): boolean {
  const cleanPBrand = normalizeForMatch(pBrandName);
  const cleanItem = normalizeForMatch(pastedItemName);
  const cleanBrand = normalizeForMatch(pastedBrandName || '');

  if (!cleanPBrand) return true; // fallback if product has no brand

  // Strict check: Never allow "Royal Stag" brand matching when the pasted item contains "Sea Link" or "Vodka"
  if (cleanItem.includes('sea link') && cleanPBrand.includes('royal stag')) return false;
  if (cleanItem.includes('royal stag') && cleanPBrand.includes('sea link')) return false;
  if (cleanItem.includes('vodka') && cleanPBrand.includes('royal stag')) return false;

  // Direct containment checks (strict)
  if (cleanItem.includes(cleanPBrand) || cleanPBrand.includes(cleanItem)) return true;
  if (cleanBrand && (cleanItem.includes(cleanBrand) || cleanBrand.includes(cleanItem))) return true;
  if (cleanBrand && (cleanBrand.includes(cleanPBrand) || cleanPBrand.includes(cleanBrand))) return true;

  // Split into words, filter out common beverage stop words, and check for intersection
  // Added "Royal", "Blue", "Gold", "White", "Black", "Star", "Link" to stop words to prevent false matches
  const stopWords = new Set(['strong', 'premium', 'beer', 'whisky', 'rum', 'vodka', 'gin', 'brandy', 'wine', 'lager', 'mild', 'deluxe', 'special', 'classic', 'original', 'super', 'bottle', 'can', 'pint', 'royal', 'blue', 'gold', 'white', 'black', 'star', 'link', 'clear', 'pure', 'select']);
  const pBrandWords = cleanPBrand.split(/\s+/).filter(w => w.length > 2 && !stopWords.has(w));
  const itemWords = cleanItem.split(/\s+/).filter(w => w.length > 2 && !stopWords.has(w));
  const brandWords = cleanBrand.split(/\s+/).filter(w => w.length > 2 && !stopWords.has(w));

  if (pBrandWords.length > 0) {
    // If any main brand word matches a word in pasted item name or pasted brand
    return pBrandWords.some(w => itemWords.includes(w) || brandWords.includes(w));
  }

  return false;
}

export function resolveCanonicalProduct(params: {
  itemName: string;
  scmCode?: string;
  brandName?: string;
  variant?: string;
  size?: number | string;
  packaging?: string;
  productId?: string;
  catalogProducts: any[];
}): ResolvedProduct | null {
  const result = _resolveCanonicalProduct(params);

  // If no database match found, provide a "VIRTUAL_MATCH" with detected brand/variant 
  // to facilitate auto-creation on the backend
  if (!result) {
    const detected = detectBrand(params.itemName, params.brandName);
    const numSize = typeof params.size === 'number' ? params.size : parseVolumeMl(params.size);
    
    return {
      productId: '', // Signals new record needed
      brandId: '',
      categoryId: '',
      packSizeId: '',
      productName: params.itemName,
      brandName: detected.brand,
      categoryName: 'Spirit', // Default fallback category
      variant: detected.brand === 'Unknown Brand' ? params.itemName : detected.variant,
      volumeMl: numSize,
      packType: params.packaging || 'Bottle',
      sku: params.scmCode || '',
      mrp: 0,
      purchasePrice: 0,
      score: 0,
      matchType: 'partial',
      resolutionStatus: 'NEW_MASTER',
      resolutionMethod: 'VIRTUAL_DETECTION',
      errorMessage: detected.brand === 'Unknown Brand' ? 'Unidentifiable Brand' : 'New Master: Brand detected automatically.',
      isNewMaster: true,
      scmCode: params.scmCode,
    };
  }

  // SCM Resolver Debug Group Log for every processed row
  console.group('SCM Resolver Debug');
  console.log('INPUT PARAMS:', {
    itemName: params.itemName,
    scmCode: params.scmCode,
    brandName: params.brandName,
    size: params.size,
    catalogProductsCount: params.catalogProducts?.length
  });
  console.log('RAW SCM:', params.scmCode || '—');
  const normScm = params.scmCode ? cleanScmCode(params.scmCode) : '';
  console.log('NORMALIZED LOOKUP SCM:', normScm || '—');
  console.log('DATABASE MATCH:', result ? (result.sku || '—') : 'NONE');
  console.log('RESOLUTION METHOD:', result ? result.resolutionMethod : 'UNRESOLVED');
  console.log('RESOLUTION STATUS:', result ? result.resolutionStatus : 'UNRESOLVED');
  console.log('IS AMBIGUOUS:', result?.isAmbiguous || false);
  if (result?.isAmbiguous) {
    console.log('POTENTIAL MATCHES:', result.potentialMatches?.map(m => m.productName));
  }
  console.groupEnd();

  return result;
}

function _resolveCanonicalProduct(params: {
  itemName: string;
  scmCode?: string;
  brandName?: string;
  variant?: string;
  size?: number | string;
  packaging?: string;
  productId?: string;
  catalogProducts: any[];
}): ResolvedProduct | null {
  const { itemName, scmCode, brandName, variant, size, packaging, productId, catalogProducts } = params;
  if (!catalogProducts || catalogProducts.length === 0) return null;

  const numSize = typeof size === 'number' ? size : parseVolumeMl(size);
  const normScm = cleanScmCode(scmCode);
  const normItem = normalizeForMatch(itemName);
  const normBrand = normalizeForMatch(brandName);
  const normVariant = normalizeForMatch(variant);
  const normPkg = normalizeForMatch(packaging || 'Bottle');

  // Robust variant compatibility checker to prevent distinct variants/flavours from merging
  const areVariantsCompatible = (pastedName: string, candidateName: string): boolean => {
    const normP = pastedName.toLowerCase();
    const normC = candidateName.toLowerCase();
    
    // Key flavour / variant identifying keywords
    const keywords = ['pure grain', 'jamun', 'spicy mint', 'vivid', 'flavoured', 'fortified', 'wine'];
    for (const kw of keywords) {
      if (normP.includes(kw) !== normC.includes(kw)) {
        return false;
      }
    }
    return true;
  };

  // Helper to build result from catalog row
  const buildResult = (p: any, score: number, matchType: ResolvedProduct['matchType']): ResolvedProduct => {
    const pid = p.id || p.productId;
    const bid = p.brand_id || p.brandId;
    const cid = p.category_id || p.categoryId || (p.category?.id);
    const psid = p.pack_size_id || p.packSizeId;
    const scmId = p.scmMasterId || p.scm_master_id || '';
    
    const pName = p.product_name || p.name || p.productName || '';
    const bName = p.brand_name || p.brandName || (p.brand?.name) || '';
    const cName = p.category_name || p.categoryName || (p.category?.name) || '';
    const vName = p.variant || p.product_name || p.name || '';
    const vol = p.volume_ml || p.volumeMl || parseVolumeMl(p.pack_size || p.pack_size_name || '');
    const pPkg = p.pack_type || p.packType || 'Bottle';
    const sku = (matchType === 'scm' && scmCode) ? scmCode.trim() : (p.sku || p.scmCode || p.scm_code || '');
    const mrp = Number(p.mrp_reference || p.mrp || 0);
    const pPrice = Number(p.purchase_tp_price || p.purchase_price || p.purchasePrice || 0);

    let method = 'FUZZY_NAME';
    if (matchType === 'scm') method = 'EXACT_SCM';
    else if (matchType === 'id') method = 'EXACT_ID';
    else if (matchType === 'product_size' || matchType === 'brand_variant_size') method = 'EXACT_PRODUCT_SIZE';
    else if (matchType === 'partial') method = 'FALLBACK';

    const resolutionStatus = (matchType === 'scm' || matchType === 'id' || matchType === 'product_size' || matchType === 'brand_variant_size') ? 'RESOLVED' : 'UNRESOLVED';

    return {
      productId: pid,
      brandId: bid,
      categoryId: cid,
      packSizeId: psid,
      scmMasterId: scmId,
      productName: pName,
      brandName: bName,
      categoryName: cName,
      variant: vName,
      volumeMl: vol,
      packType: pPkg,
      sku,
      mrp,
      purchasePrice: pPrice,
      score,
      matchType,
      resolutionMethod: method,
      resolutionStatus,
      scmCode: sku,
      scmLookupFound: matchType === 'scm',
      bottleSizeId: psid,
      packagingTypeId: pPkg,
    };
  };

  // 1. Direct SCM / SKU match (Highest priority)
  if (normScm) {
    const scmMatches = catalogProducts.filter(p => {
      const pSku = cleanScmCode(p.sku);
      const pScmCode = cleanScmCode(p.scmCode);
      const pScm_code = cleanScmCode(p.scm_code);
      return (pSku && pSku === normScm) || (pScmCode && pScmCode === normScm) || (pScm_code && pScm_code === normScm);
    });

    if (scmMatches.length > 0) {
      // Check if any matched product is compatible with pasted itemName / brandName AND exact bottle size AND variant compatibility
      const compatibleScmMatches = scmMatches.filter(p => {
        const pBrand = p.brand_name || p.brand?.name || '';
        const pVol = p.volume_ml || p.volumeMl || parseVolumeMl(p.pack_size || p.pack_size_name || '');
        const pName = p.product_name || p.name || '';
        const brandOk = !normItem || isBrandCompatible(pBrand, itemName, brandName);
        const sizeOk = numSize <= 0 || pVol <= 0 || pVol === numSize;
        const variantOk = !itemName || areVariantsCompatible(itemName, pName);
        return brandOk && sizeOk && variantOk;
      });

      if (compatibleScmMatches.length > 0) {
        if (compatibleScmMatches.length === 1) {
          return buildResult(compatibleScmMatches[0], 1000, 'scm');
        } else {
          const res = buildResult(compatibleScmMatches[0], 1000, 'scm');
          res.isAmbiguous = true;
          res.potentialMatches = compatibleScmMatches.map(m => buildResult(m, 1000, 'scm'));
          return res;
        }
      } else {
        // SCM code found in catalog, but its size or brand conflicts with source data!
        const conflictingProd = scmMatches[0];
        const confBrand = conflictingProd.brand_name || conflictingProd.brand?.name || 'Unknown';
        const confVol = conflictingProd.volume_ml || conflictingProd.volumeMl || parseVolumeMl(conflictingProd.pack_size || conflictingProd.pack_size_name || '');
        const confName = conflictingProd.product_name || conflictingProd.name || '';
        
        // If brand matches but size conflicts (e.g. catalog has 750ml, source row says 180ml or 90ml):
        if (isBrandCompatible(confBrand, itemName, brandName) && numSize > 0 && confVol > 0 && confVol !== numSize) {
          // Search catalog for product matching the same brand and exact source size and variant compatibility
          const exactSizeBrandMatch = catalogProducts.find(p => {
            const pBrand = p.brand_name || p.brand?.name || '';
            const pVol = p.volume_ml || p.volumeMl || parseVolumeMl(p.pack_size || p.pack_size_name || '');
            const pName = p.product_name || p.name || '';
            return isBrandCompatible(pBrand, itemName, brandName) && pVol === numSize && areVariantsCompatible(itemName, pName);
          });

          if (exactSizeBrandMatch) {
            const res = buildResult(exactSizeBrandMatch, 950, 'product_size');
            res.scmCode = scmCode;
            return res;
          }

          // If no catalog product exists for that size yet, preserve source size and mark for new master creation!
          const res = buildResult(conflictingProd, 100, 'scm');
          res.volumeMl = numSize; // PRESERVE SOURCE SIZE!
          res.isConflict = true;
          res.resolutionStatus = 'UNRESOLVED';
          res.errorMessage = `Size Mismatch: SCM code "${scmCode}" is registered as ${confVol} ml in catalog, but source row specifies ${numSize} ml. Review required.`;
          return res;
        }

        const res = buildResult(conflictingProd, 100, 'scm');
        if (numSize > 0) res.volumeMl = numSize; // PRESERVE SOURCE SIZE!
        res.isConflict = true;
        res.resolutionStatus = 'UNRESOLVED';
        res.errorMessage = `Conflict: SCM code is mapped to brand "${confBrand}" (${confName}), but source item is "${itemName}". Needs review.`;
        return res;
      }
    }
  }

  // 2. Exact Product ID match
  if (productId) {
    const match = catalogProducts.find(p => p.id === productId || p.productId === productId);
    if (match) return buildResult(match, 900, 'id');
  }

  // Restrict resolution by brand and size to prevent cross-brand default mapping
  if (normItem && numSize > 0) {
    // Filter catalog products by size first
    const sizeMatches = catalogProducts.filter(p => {
      const pVol = p.volume_ml || p.volumeMl || parseVolumeMl(p.pack_size || p.pack_size_name || '');
      return pVol === numSize;
    });

    // Enforce brand compatibility
    const brandMatches = sizeMatches.filter(p => {
      return isBrandCompatible(p.brand_name || p.brand?.name || '', itemName, brandName);
    });

    // Enforce variant compatibility (flavours, pure grain, etc.)
    const compatibleMatches = brandMatches.filter(p => {
      return areVariantsCompatible(itemName, p.product_name || p.name || '');
    });

    if (compatibleMatches.length > 0) {
      // 3. Product Name + Bottle Size (Strict Normalized Match within brand)
      const exactMatches = compatibleMatches.filter(p => {
        const pNameNorm = normalizeForMatch(p.product_name || p.name);
        return pNameNorm === normItem || 
               pNameNorm === `${normalizeForMatch(p.brand_name)} ${normalizeForMatch(p.product_name || p.name)}`.trim();
      });

      if (exactMatches.length === 1) {
        return buildResult(exactMatches[0], 800, 'product_size');
      } else if (exactMatches.length > 1) {
        const result = buildResult(exactMatches[0], 800, 'product_size');
        result.isAmbiguous = true;
        result.potentialMatches = exactMatches.map(m => buildResult(m, 800, 'product_size'));
        return result;
      }

      // 4. Brand + Variant + Bottle Size within brand
      if (normVariant) {
        const variantMatch = compatibleMatches.find(p => {
          const vName = normalizeForMatch(p.variant || p.product_name || p.name);
          return vName === normVariant || vName.includes(normVariant) || normVariant.includes(vName);
        });
        if (variantMatch) return buildResult(variantMatch, 700, 'brand_variant_size');
      }

      // 5. Normalized Item Name Lookup (Containment Match within brand)
      const containmentMatches = compatibleMatches.filter(p => {
        const pNameNorm = normalizeForMatch(p.product_name || p.name);
        return pNameNorm.includes(normItem) || normItem.includes(pNameNorm);
      });

      if (containmentMatches.length === 1) {
        return buildResult(containmentMatches[0], 600, 'name_size');
      } else if (containmentMatches.length > 1) {
        const result = buildResult(containmentMatches[0], 600, 'name_size');
        result.isAmbiguous = true;
        result.potentialMatches = containmentMatches.map(m => buildResult(m, 600, 'name_size'));
        return result;
      }
    }
  }

  // Fallback: Legacy fuzzy scoring logic (ONLY allowed if brand is compatible)
  const tokens = `${normBrand} ${normItem}`.split(/\s+/).filter(Boolean);
  let bestMatch: any = null;
  let highestScore = 0;

  for (const p of catalogProducts) {
    const pBrand = normalizeForMatch(p.brand?.name || p.brand_name || '');
    const pVariant = normalizeForMatch(p.product_name || p.variant || p.name || '');
    const pVolume = p.volume_ml || p.volumeMl || parseVolumeMl(p.pack_size || p.pack_size_name || '');
    const pPack = normalizeForMatch(p.pack_type || p.pack_size || '');

    if (numSize > 0 && pVolume > 0 && pVolume !== numSize) continue;

    // Strict safety check: Never fuzzy match to a totally different brand
    if (pBrand && !isBrandCompatible(pBrand, itemName, brandName)) {
      continue;
    }

    // Strict variant check: Never fuzzy match to a conflicting variant
    if (!areVariantsCompatible(itemName, p.product_name || p.name || '')) {
      continue;
    }

    const pBrandWords = pBrand.split(/\s+/).filter((w: string) => !GENERIC_STOP_WORDS.has(w) && w.length > 2);
    let brandScore = 0;
    if (pBrand) {
      if (normBrand.includes(pBrand) || normItem.includes(pBrand)) {
        brandScore += 60 + pBrand.length * 2;
      } else if (pBrandWords.length > 0 && pBrandWords.every((w: string) => tokens.includes(w))) {
        brandScore += 40 + pBrand.length;
      }
    }

    if (brandScore === 0) continue;

    const pVariantWords = pVariant.split(/\s+/).filter((w: string) => !GENERIC_STOP_WORDS.has(w) && w.length > 2);
    let variantScore = 0;
    if (pVariant) {
      if (normItem.includes(pVariant)) {
        variantScore += 30 + pVariant.length * 2;
      } else if (pVariantWords.length > 0 && pVariantWords.every((w: string) => tokens.includes(w))) {
        variantScore += 15;
      }
    }

    let score = brandScore + variantScore;
    if (numSize > 0 && pVolume === numSize) score += 40;
    if (normPkg && pPack.includes(normPkg)) score += 10;

    if (score > highestScore && score >= 70) {
      highestScore = score;
      bestMatch = p;
    }
  }

  if (bestMatch) {
    return buildResult(bestMatch, highestScore, 'partial');
  }

  return null;
}
