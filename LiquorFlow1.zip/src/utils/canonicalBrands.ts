export const CANONICAL_CATEGORY_ORDER = [
  'Whisky',
  'Rum',
  'Vodka',
  'Gin',
  'Brandy',
  'Beer',
  'Wine',
] as const;

// Production Master: Empty until populated with genuine brand master data
export const CANONICAL_BRAND_MASTER: Record<string, string[]> = {};

export function compareCanonicalBrands(nameA: string, nameB: string): number {
  return (nameA || '').localeCompare(nameB || '', undefined, { sensitivity: 'base' });
}
