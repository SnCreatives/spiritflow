import { getSupabaseServiceClient } from '../src/lib/supabase/client.js';
import dotenv from 'dotenv';
dotenv.config();

async function run() {
  const supabase = getSupabaseServiceClient();

  console.log('--- 1. Inspecting inventory table ---');
  const { data: inv, error: invErr } = await supabase.from('inventory').select('*').limit(3);
  if (invErr) {
    console.error('Inventory error:', invErr);
  } else {
    console.log('Inventory sample rows:', inv);
    if (inv && inv.length > 0) {
      console.log('Inventory columns:', Object.keys(inv[0]));
    }
  }

  console.log('--- 2. Inspecting sales_transactions ---');
  const { data: sales, error: salesErr } = await supabase.from('sales_transactions').select('*').limit(3);
  if (salesErr) {
    console.error('Sales error:', salesErr);
  } else {
    console.log('Sales transactions sample rows:', sales);
    if (sales && sales.length > 0) {
      console.log('Sales transactions columns:', Object.keys(sales[0]));
    }
  }

  console.log('--- 3. Inspecting sales_transaction_items ---');
  const { data: items, error: itemsErr } = await supabase.from('sales_transaction_items').select('*').limit(3);
  if (itemsErr) {
    console.error('Sales items error:', itemsErr);
  } else {
    console.log('Sales items sample rows:', items);
    if (items && items.length > 0) {
      console.log('Sales items columns:', Object.keys(items[0]));
    }
  }

  console.log('--- 4. Inspecting schema_migrations ---');
  const { data: migs, error: migErr } = await supabase.from('schema_migrations').select('*').order('applied_at', { ascending: false }).limit(20);
  if (migErr) {
    console.error('Migration error:', migErr);
  } else {
    console.log('Applied migrations:', migs?.map(m => m.migration_name));
  }
}

run().catch(console.error);
