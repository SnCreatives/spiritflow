import { getSupabaseServiceClient } from '../src/lib/supabase/client.js';
import dotenv from 'dotenv';
dotenv.config();

async function run() {
  const supabase = getSupabaseServiceClient();
  
  // List all functions in public schema
  const { data, error } = await supabase.rpc('get_functions', {}); // This is a guess, let's try to query pg_proc via a known table
  
  if (error) {
    console.log('Error listing functions:', error.message);
    // Try to query via information_schema
    const { data: procs, error: pErr } = await supabase
      .from('pg_proc') // This probably won't work due to RLS or permissions
      .select('*')
      .limit(1);
    
    if (pErr) {
        console.log('Cannot query pg_proc directly:', pErr.message);
    }
  } else {
    console.log('Functions:', data);
  }
}

run();
