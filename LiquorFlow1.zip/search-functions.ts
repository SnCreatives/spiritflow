import fs from 'fs';
import path from 'path';

const dir = './supabase/migrations';
const files = fs.readdirSync(dir).sort();

for (const file of files) {
  const content = fs.readFileSync(path.join(dir, file), 'utf8');
  if (content.toLowerCase().includes('create function') || content.toLowerCase().includes('create or replace function')) {
    console.log(`\n--- Found function in ${file} ---`);
    const lines = content.split('\n');
    lines.forEach((line, index) => {
      if (line.toLowerCase().includes('create function') || line.toLowerCase().includes('create or replace function')) {
        console.log(`  Line ${index + 1}: ${line.trim()}`);
      }
    });
  }
}
